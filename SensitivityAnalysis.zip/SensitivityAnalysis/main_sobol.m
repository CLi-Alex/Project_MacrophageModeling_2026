%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This code is used to sobol sensitivity analysis
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear;clc;close all
warning('off');

%% Initialize parameters
Parameter_settings;
options = odeset('MaxStep', 0.04, 'InitialStep', 0.04);

%% Time span and storage time points 
tspan = [0, 25]; 
time_points = 1:20;
num_time_points = length(time_points);

Np = length(pmin);   % number of parameters
N=10000;             % the number of rows of sobol matrix 
disp(['Number of simulations are ', num2str(N)])

%% 
% We cgenerate 2 LHS matrix A and B. 
% Also we will form the following matrices: 
%
% ABi matrix: formed by all colums of A except the k column, 
% which comes from matrix B
% 
% BAi matrix: formed by all colums of B except the k column, 
% which comes from A

A_normalized = lhsdesign(N, Np);  % lhsdesign generates uniformly distributed samples within the [0,1] interval
B_normalized = lhsdesign(N, Np);

A = zeros(N,Np);  % Map standardized samples to the actual parameter range
B = zeros(N,Np);

for i =1 : Np %looping over parameter 
A(:,i) = pmin(i) + A_normalized(:, i) * (pmax(i) - pmin(i));
B(:,i) = pmin(i) + B_normalized(:, i) * (pmax(i) - pmin(i));
end


% BAi matrices formed by all columns of B except the k column, 
% which comes from A
BAi = cell(1,Np);

for k = 1:Np
    BAi{k} = B;
    BAi{k}(:,k) = A(:,k);
end

% ABi matrices formed by all colums of A except the k column, which comes from B
ABi = cell(1,Np);
for k = 1:Np
    ABi{k} = A;
    ABi{k}(:,k) = B(:,k);
end

%% RUN
disp('Start simulating model for matrix A and B')
%% A and B
for run_num=1:N %remember to turn on for paralell computing 
%-------------------solve ODE-------------------%  
% Initialization and Parameters in loop
xA = A(run_num,:);
xB = B(run_num,:);
init_cond = [2e5;4e6;0;0];
f=@System_Model;


[TA,yA] = ode45(@(t,y)f(t,y,xA),tspan,init_cond,options);
[TB,yB] = ode45(@(t,y)f(t,y,xB),tspan,init_cond,options);


for i = 1:num_time_points
    yA_interp = interp1(TA, yA', time_points(i), 'linear', 'extrap');
    YA{run_num, i} = [yA_interp(1), yA_interp(2), yA_interp(3),yA_interp(4)]';  % 使用大括号访问cell内容
     
    yB_interp = interp1(TB, yB', time_points(i), 'linear', 'extrap');
    YB{run_num, i} = [yB_interp(1), yB_interp(2), yB_interp(3),yB_interp(4)]';
end

end %run_num=1:N

%% ABi and BAi
disp('Start simulating model for matrix ABi and BAi')
YAB = cell(1,Np);
YBA = cell(1,Np);

for k = 1:Np% loop over parameter
disp(['Simulate for parameter ', num2str(k), ' out of ',...
    num2str(Np), ' parameters'])

for run_num=1:N %loop over row of matrix 
%-------------------solve ODE-------------------%  
% Initialization and Parameters in loop
x1 = ABi{k};x2 = BAi{k};
init_cond = [2e5;4e6;0;0];
f=@System_Model;
xAB = x1(run_num,:);
xBA = x2(run_num,:);

[TAB, yAB]= ode45(@(t,y)f(t,y,xAB),tspan,init_cond,options);
[TBA, yBA]= ode45(@(t,y)f(t,y,xBA),tspan,init_cond,options);

for i = 1:num_time_points     
    yAB_interp = interp1(TAB, yAB', time_points(i), 'linear', 'extrap');
    YABi{run_num, i} = [yAB_interp(1), yAB_interp(2), yAB_interp(3),yAB_interp(4)];
    yBA_interp = interp1(TBA, yBA', time_points(i), 'linear', 'extrap');
    YBAi{run_num, i} = [yBA_interp(1), yBA_interp(2), yBA_interp(3),yBA_interp(4)];
end
         
    end %runnum
    
    disp(['Compute variance for parameter p',num2str(k)])
    YAB{k} = YABi;        
    YBA{k} = YBAi;
end

%% data processing
for i =1:25
    for j = 1:N

       
        YA_C(j,i) = YA{j,i}(1);
        YA_M1(j,i) = YA{j,i}(2);
        YA_M2(j,i) = YA{j,i}(3);
        YA_M3(j,i) = YA{j,i}(4);
       
        YB_C(j,i) = YB{j,i}(1);
        YB_M1(j,i) = YB{j,i}(2);
        YB_M2(j,i) = YB{j,i}(3);
        YB_M3(j,i) = YB{j,i}(4);

    end
end


for k = 1:Np
for i =1:25
    for j = 1:N
        YAB_1(j,i) = YAB{1,k}{j,i}(1);
        YAB_C{i,k} =  YAB_1(:,i);
        
        YAB_2(j,i) = YAB{1,k}{j,i}(2);
        YAB_M1{i,k} =  YAB_2(:,i);
        
        YAB_3(j,i) = YAB{1,k}{j,i}(3);
        YAB_M2{i,k} =  YAB_3(:,i);
        
        YAB_4(j,i) = YAB{1,k}{j,i}(4);
        YAB_M3{i,k} =  YAB_4(:,i);
        
    end
end

end

for k = 1:Np
for i =1:25
    for j = 1:N
        YBA_1(j,i) = YBA{1,k}{j,i}(1);
        YBA_C{i,k} =  YBA_1(:,i);
        
        YBA_2(j,i) = YBA{1,k}{j,i}(2);
        YBA_M1{i,k} =  YBA_2(:,i);
        
        YBA_3(j,i) = YBA{1,k}{j,i}(3);
        YBA_M2{i,k} =  YBA_3(:,i);
        
        YBA_4(j,i) = YBA{1,k}{j,i}(4);
        YBA_M3{i,k} =  YBA_4(:,i);
        
    end
end

end
% save 'sobol_matrix.mat'

%% An example of calculating the first order and total order sensitivity index of C
for i = 1:25
Vtot_C=var([YA_C(:,i)]); % total variance 

for k = 1:Np             % loop over parameter
disp(['Simulate for parameter ', num2str(k), ' out of ',...
    num2str(Np), ' parameters'])

    Vi_C  =  mean(YA_C(:,i).*YBA_C{i,k})-mean([YA_C(:,i)]).^2;    
    VTi_C =  mean((YA_C(:,i)-YAB_C{i,k}).^2)/2;

    C_S_vec(k) = Vi_C./Vtot_C;
    C_ST_vec(k) = VTi_C./Vtot_C;
end

% Si and STi
Si_C(:,i) = C_S_vec';
STi_C(:,i) = C_ST_vec';

end

% save('Result_C/Si_C.mat','Si_C');
% save('Result_C/STi_C.mat','STi_C');