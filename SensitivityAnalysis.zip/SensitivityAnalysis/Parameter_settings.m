% Parameter Labels 

Parameter_var = {'alpha','K','delta','p','eta','kappa','gamma','lambda','M0','beta13','beta32','K0','K1','K2','d1','d2','d3'};

baseline = [
    0.431;       % alpha
    3e8;         % K
    1e-9;        % delta
    0.5;         % p
    1.1e-8;      % eta
    0.4;         % kappa
    0.1;         % gamma
    0.5;         % lambda
    4e5;         % M0
    0.5;         % beta13
    0.5;         % beta32
    3e7;         % K0
    3e6;         % K1
    3e6;         % K2
    0.056;       % d1
    0.056;       % d2
    0.056        % d3
];
%%
a = 0.1;
pmin = [
    0.431 * (1 - a);       % alpha
    3e8 * (1 - a);         % K
    1e-9 * (1 - a);        % delta
    0.5 * (1 - a);         % p
    1.1e-8 * (1 - a);      % eta
    0.4 * (1 - a);         % kappa
    0.1 * (1 - a);         % gamma
    0.5 * (1 - a);         % lambda
    4e5 * (1 - a);         % M0
    0.5 * (1 - a);         % beta13
    0.5 * (1 - a);         % beta32
    3e7 * (1 - a);         % K0
    3e6 * (1 - a);         % K1
    3e6 * (1 - a);         % K2
    0.056 * (1 - a);       % d1
    0.056 * (1 - a);       % d2
    0.056 * (1 - a)        % d3
];
%%
pmax = [
    0.431 * (1 + a);       % alpha
    3e8 * (1 + a);         % K
    1e-9 * (1 + a);        % delta
    0.5 * (1 + a);         % p
    1.1e-8 * (1 + a);      % eta
    0.4 * (1 + a);         % kappa
    0.1 * (1 + a);         % gamma
    0.5 * (1 + a);         % lambda
    4e5 * (1 + a);         % M0
    0.5 * (1 + a);         % beta13
    0.5 * (1 + a);         % beta32
    3e7 * (1 + a);         % K0
    3e6 * (1 + a);         % K1
    3e6 * (1 + a);         % K2
    0.056 * (1 + a);       % d1
    0.056 * (1 + a);       % d2
    0.056 * (1 + a)        % d3
];
