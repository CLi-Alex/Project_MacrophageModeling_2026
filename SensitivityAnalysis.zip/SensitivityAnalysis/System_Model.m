function dy = System_Model(t,y, params)

%% Model Variable
C = y(1);  M1 = y(2);  M2 = y(3);  M3 = y(4);

%% Parameters

alpha = params(1);
K     = params(2);
delta = params(3);
p     = params(4);
eta   = params(5);
kappa = params(6);
gamma = params(7);
lambda = params(8);
M0    = params(9);
beta13 = params(10);
beta31 = 0;
beta23 = 0;
beta32 = params(11);
K0     = params(12);
K1     = params(13);
K2     = params(14);
d1     = params(15);
d2     = params(16);
d3     = params(17);




%% Definition of Differential Equations

dCdt = alpha * (1 + delta * (M2 + p * M3)) * (1 - C/K) * C ...
       - eta * (M1 + (1 - p) * M3) * C;

dM1dt = kappa * M0 - beta13 * C/(K1 + C) * M1 + beta31 * M3 - d1 * M1;

dM2dt = gamma * (1 + lambda * C/(K0 + C)) * M0 - beta32 * C/(K2 + C) * M3 ...
       - beta23 * M2 - d2 * M2;

dM3dt = beta13 * C/(K1 + C) * M1 - beta31 * M3 - beta32 * C/(K2 + C) * M3 ...
       + beta23 * M2 - d3 * M3;

dy = [dCdt; dM1dt; dM2dt; dM3dt];

end
