function Y = ABC_Model(M)
% ABC_MODEL Simulates the ABC model dynamics using Euler integration.
%   This function integrates the system of ordinary differential equations
%   (ODEs) defined in ode_system() over a specified time interval. The
%   model parameters are loaded from a separate parameters() function and
%   partially overridden by the input vector M.
%
%   Input:
%       M : [1x8] vector of parameter values that override the defaults:
%           M(1) = alpha,  M(2) = K,      M(3) = M0,    M(4) = kappa,
%           M(5) = beta13, M(6) = beta32, M(7) = eta,   M(8) = p.
%
%   Output:
%       Y : [4 x n_steps] matrix where each column corresponds to the
%           state vector [y1; y2; y3; y4] at a given time point.

% -----------------------------------------------------------------
% 1. Load default model parameters
% -----------------------------------------------------------------
params = parameters();          % Retrieve default parameter structure
params.alpha  = M(1);           % Override alpha parameter
params.K      = M(2);           % Override K parameter
params.M0     = M(3);           % Override M0 parameter
params.kappa  = M(4);           % Override kappa parameter
params.beta13 = M(5);           % Override beta13 parameter
params.beta32 = M(6);           % Override beta32 parameter
params.eta    = M(7);           % Override eta parameter
params.p      = M(8);           % Override p parameter

% -----------------------------------------------------------------
% 2. Define the time discretization
% -----------------------------------------------------------------
tspan = params.t_start:params.dt:params.t_end;   % Time grid from start to end
n_steps = length(tspan);                         % Total number of time steps

% -----------------------------------------------------------------
% 3. Initialize storage for the solution
% -----------------------------------------------------------------
Y = zeros(4, n_steps);          % Pre-allocate memory for state trajectories
Y(:, 1) = params.y0';           % Set initial conditions (transpose to column)

% -----------------------------------------------------------------
% 4. Integrate the ODE system using the forward Euler method
% -----------------------------------------------------------------
for i = 1:n_steps-1
    % Compute the state at the next time step:
    %   Y(:, i+1) = Y(:, i) + dt * f(t_i, Y(:, i))
    Y(:, i+1) = Y(:, i) + params.dt * ode_system(tspan(i), Y(:, i), params);
end

end