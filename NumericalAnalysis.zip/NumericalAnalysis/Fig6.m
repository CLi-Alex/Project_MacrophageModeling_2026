function Fig6()
% FIG6 Plots ABC results for 8 mice: best‑fit tumor growth curves,
%      posterior ranges, and R² histograms.
%   This function loads the ABC posterior outputs (Tumor volumes and R² values)
%   from the 'Data' folder, generates a 2x4 subplot figure showing the
%   best‑fit trajectory, the 95% posterior interval, and experimental data
%   for each mouse, followed by a second figure with histograms of R²
%   values for all accepted parameter sets.

    % ====================================================================
    % 1.  Load ABC results
    % ====================================================================
    % Load tumor volume trajectories (from ABC posterior, size: [Num, time, 8])
    load('Data/Tumor.mat', 'Tumor');   % Tumor(:,:,i) for mouse i
    % Load R² values (size: [8, Num] where rows = mice, columns = parameter sets)
    load('Data/R.mat', 'R');           % R(i,:) for mouse i

    % ====================================================================
    % 2.  Experimental data (time points and mean tumor volumes)
    % ====================================================================
    % Each mouse has 2 rows: row1 = time points (days), row2 = tumor volumes (mm³)
    ExpData = [8, 11, 13, 15, 18, 20, 23;   86, 268.02, 430.35, 670.93, 1103.47, 1556.73, 1732.68;
               8, 11, 13, 15, 18, 20, 23;   74.66, 284.71, 430.71, 619.76, 1033.08, 1350.51, 1705.42;
               8, 11, 13, 15, 18, 20, 23;   72, 200.29, 326.36, 610.41, 1267.32, 1646, 2645.34;
               8, 11, 13, 15, 18, 20, 23;   71.54, 195.76, 351.1, 680.19, 1171.53, 1716.05, 2412.35;
               8, 11, 13, 15, 18, 20, NaN;  62, 211.76, 454.96, 840.17, 1960.9, 2388.14, NaN;
               8, 11, 13, 15, 18, 20, 23;   47.7, 190.33, 371.4, 608.32, 860.8, 1265.47, 1807.26;
               8, 11, 13, 15, 18, 20, 23;   39.64, 145.12, 214.51, 340.28, 540.06, 893.15, 1340.64;
               8, 11, 13, 15, 18, 20, 23;   23.88, 86.49, 164.9, 315, 596.66, 1015.85, 1705.9];

    % ====================================================================
    % 3.  Figure 1: Best‑fit curves with posterior intervals and data points
    % ====================================================================
    figure();   % Create new figure

    % Visual parameters
    Color = ColorMatrix();                % Predefined colour palette
    time = 0:0.01:31;                    % Simulation time vector (days)
    lineWidth = 1;
    fontSize = 12;
    markerSize = 50;
    nbins = 15;                          % Number of bins for histograms

    % Pre‑select colours for lines and points (8 mice)
    colorsLine = {cell2mat(Color(1,9)); cell2mat(Color(1,10)); cell2mat(Color(1,1));
                  cell2mat(Color(3,1)); cell2mat(Color(5,1)); cell2mat(Color(1,11));
                  cell2mat(Color(1,13)); cell2mat(Color(5,13))};
    colorsPoint = {cell2mat(Color(3,9)); cell2mat(Color(3,10)); cell2mat(Color(3,1));
                   cell2mat(Color(5,1)); cell2mat(Color(7,1)); cell2mat(Color(3,11));
                   cell2mat(Color(1,13)); cell2mat(Color(5,13))};

    for i = 1:8   % Loop over the 8 mice
        subplot(2, 4, i);
        hold on; box on; grid on;

        % Identify the best‑fit parameter set (highest R²) for this mouse
        [~, bestIdx] = max(R(i, :));

        % Convert model tumor cell counts to volume (mm³) and scale to ×10³ mm³
        % Tumor(:,:,i) is [Num × time] (Num parameter sets, time points)
        Data = Tumor(:, :, i) .* 6.95e-9;   % Convert cells → mm³

        % Compute envelope (max/min) across all posterior parameter sets
        Max = max(Data, [], 1);
        Min = min(Data, [], 1);

        % Plot best‑fit curve (solid line)
        plot(time, Data(bestIdx, :), '-', 'LineWidth', lineWidth + 1, ...
             'Color', colorsLine{i});

        % Plot posterior envelope (filled area)
        fill([time, fliplr(time)], [Max, fliplr(Min)], ...
             colorsPoint{i}, 'FaceAlpha', 0.3, 'EdgeColor', 'none');

        % Plot experimental data (scatter points)
        % For mouse 5, the last data point is NaN, so only first 6 time points
        if i == 5
            scatter(ExpData(2*i-1, 1:6), ExpData(2*i, 1:6) * 1e-3, markerSize, ...
                    'MarkerEdgeColor', colorsLine{i}, ...
                    'MarkerFaceColor', colorsPoint{i}, 'LineWidth', lineWidth + 1);
        else
            scatter(ExpData(2*i-1, :), ExpData(2*i, :) * 1e-3, markerSize, ...
                    'MarkerEdgeColor', colorsLine{i}, ...
                    'MarkerFaceColor', colorsPoint{i}, 'LineWidth', lineWidth + 1);
        end

        % Plot envelope boundaries (dotted lines)
        plot(time, Max, ':', 'LineWidth', lineWidth, 'Color', colorsLine{i});
        plot(time, Min, ':', 'LineWidth', lineWidth, 'Color', colorsLine{i});

        % Display R² of the best‑fit model
        text(0.1, 0.5, sprintf('R² = %.3f', R(i, bestIdx)), ...
             'Units', 'normalized', 'FontSize', fontSize + 2, 'FontWeight', 'bold');

        % Axis settings
        xlim([0, 25]);
        ylim([0, 3.25]);
        xlabel('Time (days)');
        ylabel('Tumor volume (\times 10^3 mm^3)');
        title(sprintf('Mouse %d', i));
        set(gca, 'FontSize', fontSize, 'FontName', 'Arial');
        legend('Best fit', 'Posterior inference', 'Data', 'Location', 'northwest');
    end

    

    % Save Figure 1
    set(gcf, 'Unit', 'centimeters', 'Position', [3, 10, 48, 18]);
    print('Figure/Fig6A', '-dpng', '-r200');

    % ====================================================================
    % 4.  Figure 2: Histograms of R² for each mouse
    % ====================================================================
    figure();   % Create new figure for histograms

    for i = 1:8
        subplot(2, 4, i);
        hold on; grid on; box on;

        % Plot histogram of R² values for this mouse
        histogram(R(i, :), nbins, 'FaceColor', colorsPoint{i});

        xlabel('R²');
        ylabel('Count');
        title(sprintf('Mouse %d', i));
        set(gca, 'FontSize', fontSize, 'FontName', 'Arial');
    end

    % Save Figure 2
    set(gcf, 'Unit', 'centimeters', 'Position', [3, 10, 48, 10]);
    print('Figure/Fig6B', '-dpng', '-r200');

end