function params = parameters()
% PARAMETERS Defines default parameters for the tumor-macrophage interaction model.
%   This function creates a structure containing all model parameters,
%   including tumor growth parameters, macrophage dynamics, transformation rates,
%   death rates, Hill function constants, initial conditions, and simulation settings.
%
%   Output:
%       params - Structure with fields for each parameter used in the model.

    close all;   % Close any open figures for a clean workspace

    % -----------------------------------------------------------------
    % 1. Tumor growth parameters
    % -----------------------------------------------------------------
    params.alpha = 0.431;     % Intrinsic tumor growth rate (day⁻¹)
    params.delta = 1e-9;      % Enhancement factor of tumor growth by pro‑tumor macrophages (M2 and p·M3)
    params.K = 3e8;           % Tumor carrying capacity (maximum cell count) [cells]
                              % Source: Lai, Bull Math Biol, 2025
    params.eta = 1.1e-8;      % Killing rate of tumor cells by anti‑tumor macrophages (M1 and (1‑p)·M3) [cells⁻¹·day⁻¹]
    params.p = 0.5;           % Fraction of M3 macrophages that behave as pro‑tumor (0 ≤ p ≤ 1)

    % -----------------------------------------------------------------
    % 2. Macrophage transformation (polarization) rates
    % -----------------------------------------------------------------
    params.kappa = 0.4;       % Basal polarization rate of M0 precursors to M1 macrophages (day⁻¹)
    params.beta13 = 0.5;      % Rate of M1 → M3 conversion (day⁻¹)
    params.beta31 = 0;        % Rate of M3 → M1 conversion (day⁻¹)
    params.beta32 = 0.5;      % Rate of M3 → M2 conversion (day⁻¹)
    params.beta23 = 0;        % Rate of M2 → M3 conversion (day⁻¹)

    % -----------------------------------------------------------------
    % 3. Macrophage death rates
    % -----------------------------------------------------------------
    params.d1 = 0.056;        % Natural death rate of M1 macrophages (day⁻¹)
    params.d2 = 0.056;        % Natural death rate of M2 macrophages (day⁻¹)
    params.d3 = 0.056;        % Natural death rate of M3 macrophages (day⁻¹)

    % -----------------------------------------------------------------
    % 4. M2 polarization parameters
    % -----------------------------------------------------------------
    params.gamma  = 0.1;      % Basal polarization rate of M0 → M2 (day⁻¹)
    params.lambda = 0.5;      % Maximal fold‑increase in M0 → M2 polarization due to tumor stimulation

    % -----------------------------------------------------------------
    % 5. Hill function parameters (sigmoidal activation by tumor cells)
    % -----------------------------------------------------------------
    params.K0 = 3e7;          % Half‑saturation constant for tumor‑induced M2 polarization [cells]
    params.K1 = 3e6;          % Half‑saturation constant for M1 → M3 conversion [cells]
    params.K2 = 3e6;          % Half‑saturation constant for M3 → M2 conversion [cells]

    % -----------------------------------------------------------------
    % 6. Constant precursor population
    % -----------------------------------------------------------------
    params.M0 = 4e5;          % Constant recruitment rate of M0 macrophages [cells·day⁻¹]

    % -----------------------------------------------------------------
    % 7. Simulation time settings
    % -----------------------------------------------------------------
    params.t_start = 0;       % Start time of the simulation (days)
    params.t_end   = 31;      % End time of the simulation (days)
    params.dt      = 0.01;    % Time step for numerical integration (days)

    % -----------------------------------------------------------------
    % 8. Initial conditions for the four state variables
    % -----------------------------------------------------------------
    params.y0 = [2e5, 4e6, 0, 0];   % [C, M1, M2, M3] at t = 0

end