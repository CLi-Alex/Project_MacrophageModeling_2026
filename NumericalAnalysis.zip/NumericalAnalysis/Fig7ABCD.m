function Fig7ABCD()
% FIG7ABCD Plots tumor AUC bar chart and mean macrophage dynamics for 8 mice.
%   This function loads ABC posterior results (Tumor, M1, M2, M3) from the
%   'Data' folder, computes the Area Under the Curve (AUC) for tumor cell
%   counts (NOT volume), and generates a 2×2 subplot figure showing:
%       1) Bar plot of tumor AUC (scaled by 1e-9) with error bars.
%       2) Mean M1 macrophage dynamics over time.
%       3) Mean M3 macrophage dynamics over time.
%       4) Mean M2 macrophage dynamics over time.
%   The figure is saved as 'Figure/Fig7ABCD.png' at 200 dpi.
%
%   NOTE: The original manuscript plots AUC as "×10^9 mm³", but the raw data
%         is cell counts integrated over time. The scaling factor 1e-9 is
%         applied only for visualisation and does NOT convert to volume.
%         This replicates the original figure exactly.

    % ====================================================================
    % 1. Load ABC posterior data and extract time series for each mouse
    % ====================================================================
    Q = 2501;   % Number of time points (0-25 days, dt=0.01)

    % Load 3D arrays: [Num × time × mouse]
    T_data = cell2mat(struct2cell(load('./Data/Tumor.mat')));   % Tumor cell counts
    M1_data = cell2mat(struct2cell(load('./Data/M1.mat')));     % M1 macrophages
    M2_data = cell2mat(struct2cell(load('./Data/M2.mat')));     % M2 macrophages
    M3_data = cell2mat(struct2cell(load('./Data/M3.mat')));     % M3 macrophages

    % Extract time series for each mouse (first Q time points)
    T = cell(8,1);
    M1 = cell(8,1);
    M2 = cell(8,1);
    M3 = cell(8,1);
    for i = 1:8
        T{i}  = T_data(:, 1:Q, i);
        M1{i} = M1_data(:, 1:Q, i);
        M2{i} = M2_data(:, 1:Q, i);
        M3{i} = M3_data(:, 1:Q, i);
    end

    % ====================================================================
    % 2. Compute tumor Area Under the Curve (AUC) for each mouse
    %    IMPORTANT: Integration is performed on cell counts (NOT volume).
    %    The final bar heights are multiplied by 1e-9 only for plotting,
    %    matching the original figure's scaling.
    % ====================================================================
    time = 0:0.01:25;          % Time vector (days)
    integral = zeros(8,1);
    std_value = zeros(8,1);

    for i = 1:8
        % Integrate tumor cell counts over time (trapezoidal rule)
        % Each row corresponds to one parameter set; integrate across columns
        T_auc = trapz(time, T{i}, 2);   % [Num × 1]
        integral(i) = mean(T_auc);
        std_value(i) = std(T_auc);
    end

    % ====================================================================
    % 3. Define visual parameters and colour palette
    % ====================================================================
    Color = ColorMatrix();
    fontSize = 14;
    lineWidth = 2;

    % Colours for each mouse (from ColorMatrix)
    colors = {cell2mat(Color(3,9));  cell2mat(Color(3,10)); cell2mat(Color(3,1));
              cell2mat(Color(5,1));  cell2mat(Color(7,1));  cell2mat(Color(3,11));
              cell2mat(Color(3,13)); cell2mat(Color(5,13))};

    mouseNames = {'Mouse 1', 'Mouse 2', 'Mouse 3', 'Mouse 4', ...
                  'Mouse 5', 'Mouse 6', 'Mouse 7', 'Mouse 8'};

    % ====================================================================
    % 4. Create figure with 2×2 subplots
    % ====================================================================
    figure();

    % --------------------------------------------------------------------
    % Subplot 1: Tumor AUC bar chart with error bars
    % --------------------------------------------------------------------
    subplot(2,2,1);
    hold on; grid on; box on;
    h = bar(mouseNames, integral * 1e-9);   % Scale to ×10⁹ for plotting
    h.FaceColor = 'flat';
    h.CData = vertcat(colors{:});           % Assign unique colour per bar
    errorbar(1:8, integral * 1e-9, std_value * 1e-9, 'k.', ...
             'LineWidth', lineWidth-1, 'CapSize', 15);
    yline(2.4, 'r--', 'LineWidth', lineWidth);
    yline(1.8, 'b--', 'LineWidth', lineWidth);
    ylim([1 3.5]);
    ylabel('Tumor AUC (\times 10^9 cells)');
    set(gca, 'FontSize', fontSize, 'FontName', 'Arial');

    % --------------------------------------------------------------------
    % Subplot 2: Mean M1 macrophage dynamics
    % --------------------------------------------------------------------
    subplot(2,2,2);
    hold on; grid on; box on;
    for i = 1:8
        plot(time, mean(M1{i}, 1), '-o', ...
             'Color', colors{i}, 'LineWidth', lineWidth, ...
             'MarkerIndices', 1:300:length(time), ...
             'MarkerSize', 6, ...
             'MarkerFaceColor', [1 1 1], ...
             'MarkerEdgeColor', colors{i});
    end
    ylabel('Mean M1-type dynamics');
    legend(mouseNames, 'Location', 'northeast', 'NumColumns', 2);
    xlabel('Time (days)');
    xlim([0 25]); ylim([0 4e6]);
    set(gca, 'FontSize', fontSize, 'FontName', 'Arial');

    % --------------------------------------------------------------------
    % Subplot 3: Mean M3 macrophage dynamics
    % --------------------------------------------------------------------
    subplot(2,2,3);
    hold on; grid on; box on;
    for i = 1:8
        plot(time, mean(M3{i}, 1), '-s', ...
             'Color', colors{i}, 'LineWidth', lineWidth, ...
             'MarkerIndices', 1:300:length(time), ...
             'MarkerSize', 6, ...
             'MarkerFaceColor', [1 1 1], ...
             'MarkerEdgeColor', colors{i});
    end
    ylabel('Mean M3-type dynamics');
    legend(mouseNames, 'Location', 'northeast', 'NumColumns', 2);
    xlabel('Time (days)');
    xlim([0 25]); ylim([0 2.5e6]);
    set(gca, 'FontSize', fontSize, 'FontName', 'Arial');

    % --------------------------------------------------------------------
    % Subplot 4: Mean M2 macrophage dynamics
    % --------------------------------------------------------------------
    subplot(2,2,4);
    hold on; grid on; box on;
    for i = 1:8
        plot(time, mean(M2{i}, 1), '-^', ...
             'Color', colors{i}, 'LineWidth', lineWidth, ...
             'MarkerIndices', 1:300:length(time), ...
             'MarkerSize', 6, ...
             'MarkerFaceColor', [1 1 1], ...
             'MarkerEdgeColor', colors{i});
    end
    ylabel('Mean M2-type dynamics');
    legend(mouseNames, 'Location', 'southeast', 'NumColumns', 2);
    xlabel('Time (days)');
    xlim([0 25]); ylim([0 4e6]);
    set(gca, 'FontSize', fontSize, 'FontName', 'Arial');

    % ====================================================================
    % 5. Save the figure
    % ====================================================================
    set(gcf, 'Unit', 'centimeters', 'Position', [3, 10, 30, 24]);
    print('Figure/Fig7ABCD', '-dpng', '-r200');

end