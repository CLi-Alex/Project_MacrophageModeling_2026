function main()
% MAIN Driver function for the tumor-macrophage interaction model.
%   This function loads model parameters, sets up the time domain,
%   integrates the system of ordinary differential equations (ODEs)
%   using the forward Euler method, and then plots the results by
%   calling the Fig2() plotting function.
%
%   The ODE system describes the dynamics of four state variables:
%       C  : tumor cell population
%       M1 : M1 macrophage population (pro-inflammatory)
%       M2 : M2 macrophage population (anti-inflammatory)
%       M3 : M3 macrophage population (other/subtype)
%
%   No input arguments are required. The function does not return any
%   output; results are displayed graphically.

    % -----------------------------------------------------------------
    % 1. Load model parameters from the parameters() function
    % -----------------------------------------------------------------
    params = parameters();

    % -----------------------------------------------------------------
    % 2. Create the time vector for the simulation
    % -----------------------------------------------------------------
    tspan = params.t_start:params.dt:params.t_end;   % Discrete time points
    n_steps = length(tspan);                         % Total number of steps

    % -----------------------------------------------------------------
    % 3. Initialize storage for the solution
    % -----------------------------------------------------------------
    Y = zeros(4, n_steps);                           % Pre-allocate (4 states)
    Y(:, 1) = params.y0';                            % Set initial conditions

    % -----------------------------------------------------------------
    % 4. Integrate the ODE system using the forward Euler method
    % -----------------------------------------------------------------
    for i = 1:n_steps-1
        % Compute the state at the next time step:
        %   Y(:, i+1) = Y(:, i) + dt * f(t_i, Y(:, i))
        Y(:, i+1) = Y(:, i) + params.dt * ode_system(tspan(i), Y(:, i), params);

        % Optional: Enforce non‑negative values to prevent biologically
        % unrealistic negative populations. This line is currently commented
        % out but can be activated if needed.
        % Y(:, i+1) = max(Y(:, i+1), 0);
    end

    % -----------------------------------------------------------------
    % 5. Extract individual state variables for plotting
    % -----------------------------------------------------------------
    C  = Y(1, :);   % Tumor cells
    M1 = Y(2, :);   % M1 macrophages
    M2 = Y(3, :);   % M2 macrophages
    M3 = Y(4, :);   % M3 macrophages

    % -----------------------------------------------------------------
    % 6. Plot the simulation results
    % -----------------------------------------------------------------
    Fig2(tspan, C, M1, M2, M3);

end