function Fig10()
% FIG10 Plots survival curves and correlations with M1/M3 biomarkers.
%   This function loads ABC posterior results for 8 mice, computes:
%       1) M1 AUC (area under curve) and M3 peak time.
%       2) Death times from the survival model.
%   It generates two figures:
%       Fig10A: Kaplan‑Meier survival curves for each mouse, with median
%               survival time (M‑OS) markers.
%       Fig10BCDE: Four scatter plots showing correlations between
%               (M1 AUC, M‑OS), (M1 AUC, death time),
%               (M3 peak time, M‑OS), (M3 peak time, death time).
%   Figures are saved in the 'Figure' folder.

    % ====================================================================
    % 1. Load data and define common parameters
    % ====================================================================
    % Load M1 and M3 macrophage trajectories (each: [100 samples × 2501 time points × 8 mice])
    M1 = cell2mat(struct2cell(load('./Data/M1.mat')));
    M3 = cell2mat(struct2cell(load('./Data/M3.mat')));
    % Load death times (800 × 1)
    Death = cell2mat(struct2cell(load('./Data/death_times.mat')));

    % Time vector (0 to 25 days, dt = 0.01)
    time = 0:0.01:25;
    n_mice = 8;
    n_samples_per_mouse = 100;

    % Scaling factors (from original code)
    scale_M1_AUC = 1e-7;    % Convert M1 AUC to ×10^7 cells
    scale_M3_peak = 0.01;   % Convert index to days (since dt=0.01)

    % Colour palette (from ColorMatrix)
    Color = ColorMatrix();
    colors = {cell2mat(Color(3,9));  cell2mat(Color(3,10)); cell2mat(Color(3,1));
              cell2mat(Color(5,1));  cell2mat(Color(5,1));  cell2mat(Color(3,11));
              cell2mat(Color(3,13)); cell2mat(Color(5,13))};
    mouseNames = {'Mouse 1', 'Mouse 2', 'Mouse 3', 'Mouse 4', ...
                  'Mouse 5', 'Mouse 6', 'Mouse 7', 'Mouse 8'};

    % ====================================================================
    % 2. Compute M1 AUC and M3 peak time for each mouse
    % ====================================================================
    M1_AUC = cell(n_mice, 1);        % [100 × 1] for each mouse
    M3_peak = cell(n_mice, 1);       % [100 × 1] for each mouse

    for i = 1:n_mice
        % M1 AUC (trapezoidal integration over time)
        M1_i = M1(:, 1:length(time), i);       % [100 × time]
        M1_AUC{i} = trapz(time, M1_i, 2);      % [100 × 1]

        % M3 peak time (index of maximum, scaled to days)
        M3_i = M3(:, 1:length(time), i);       % [100 × time]
        [~, peak_idx] = max(M3_i, [], 2);      % [100 × 1] index (1‑based)
        M3_peak{i} = peak_idx * scale_M3_peak; % [100 × 1] days
    end

    % Compute group means (scaled) for correlation plots
    M1_mean = cellfun(@(x) mean(x) * scale_M1_AUC, M1_AUC);
    M3_mean = cellfun(@(x) mean(x), M3_peak);  % already scaled

    % ====================================================================
    % 3. Figure 10A: Kaplan‑Meier survival curves per mouse
    % ====================================================================
    figure();
    hold on; grid on; box on;

    median_times = zeros(n_mice, 1);   % Median survival time per mouse

    for i = 1:n_mice
        % Extract death times for this mouse (100 samples)
        idx = (i-1)*n_samples_per_mouse + (1:n_samples_per_mouse);
        times = Death(idx);

        % Compute empirical survival function
        t_sorted = sort(times);
        n = length(t_sorted);
        survival = (n:-1:1)' / n;          % survival probability
        x_data = [0; t_sorted];
        y_data = [1; survival];

        % Plot step function
        stairs(x_data, y_data * 100, 'Color', colors{i}, 'LineWidth', 2);

        % Find median survival time (closest to 0.5)
        [~, idx_closest] = min(abs(y_data - 0.5));
        median_times(i) = x_data(idx_closest);
    end

    % Mark median survival times on the plot
    for i = 1:n_mice
        scatter(median_times(i), 50, 9+120, ...      % MarkerSize = 9+120
                'MarkerFaceColor', colors{i}, ...
                'MarkerEdgeColor', [1 1 1]);
    end

    legend(mouseNames, 'Location', 'southwest', 'NumColumns', 1, 'FontSize', 14);
    xlim([20, 30]);
    xlabel('Time (days)');
    ylabel('Survival rate (%)');
    set(gca, 'FontSize', 14, 'FontName', 'Arial');
    set(gcf, 'Unit', 'centimeters', 'Position', [3, 10, 20, 20]);
    print('Figure/Fig10A', '-dpng', '-r200');

    % ====================================================================
    % 4. Figure 10BCDE: Four correlation subplots
    % ====================================================================
    figure();
    fontSize = 14;
    lineWidth = 2;
    markerSize_group = 9 + 100;   % original MarkerSize+100
    markerSize_indiv = 9 + 70;    % original MarkerSize+70

    % ----- Subplot 1: M1 AUC (group mean) vs median survival time -----
    subplot(2, 2, 1);
    hold on; grid on; box on;
    for i = 1:n_mice
        scatter(M1_mean(i), median_times(i), markerSize_group, ...
                'MarkerEdgeColor', [1 1 1], ...
                'MarkerFaceColor', colors{i}, 'LineWidth', 1.5);
    end
    p = polyfit(M1_mean, median_times, 1);
    plot(M1_mean, polyval(p, M1_mean), '-', 'Color', [0 0 0], 'LineWidth', 1.5);
    [R_mat, P_mat] = corrcoef(M1_mean, median_times);
    R_val = R_mat(1,2); P_val = P_mat(1,2);
    if P_val < 0.001; p_text = 'p < 0.001';
    elseif P_val < 0.01; p_text = sprintf('p = %.2f', P_val);
    else p_text = sprintf('p = %.2f', P_val); end
    text(0.1, 0.8, sprintf('R = %.2f\n%s', R_val, p_text), ...
         'Color', [0 0 0], 'FontSize', fontSize+2, 'Units', 'normalized');
    legend(mouseNames, 'Location', 'southeast', 'NumColumns', 1, 'FontSize', fontSize-3);
    title('Group');
    xlim([2.5, 5.5]);
    xlabel('M1-type macrophages AUC (\times 10^7 cell)');
    ylabel('M-OS (days)');
    set(gca, 'FontSize', fontSize, 'FontName', 'Arial');

    % ----- Subplot 2: M1 AUC (individual) vs death time -----
    subplot(2, 2, 2);
    hold on; grid on; box on;
    x_all = []; y_all = [];
    for i = 1:n_mice
        x = M1_AUC{i} * scale_M1_AUC;
        y = Death((i-1)*n_samples_per_mouse+1 : i*n_samples_per_mouse);
        scatter(x, y, markerSize_indiv, ...
                'MarkerEdgeColor', [1 1 1], ...
                'MarkerFaceColor', colors{i});
        x_all = [x_all; x];
        y_all = [y_all; y];
    end
    p = polyfit(x_all, y_all, 1);
    plot(x_all, polyval(p, x_all), '-', 'Color', [0 0 0], 'LineWidth', lineWidth);
    [R_mat, P_mat] = corrcoef(x_all, y_all);
    R_val = R_mat(1,2); P_val = P_mat(1,2);
    if P_val < 0.001; p_text = 'p < 0.001';
    elseif P_val < 0.01; p_text = sprintf('p = %.3f', P_val);
    else p_text = sprintf('p = %.2f', P_val); end
    text(0.7, 0.2, sprintf('R = %.2f\n%s', R_val, p_text), ...
         'Color', [0 0 0], 'FontSize', fontSize+2, 'Units', 'normalized');
    xlim([1.3, 11]); ylim([21, 30]);
    title('Individual');
    xlabel('M1-type macrophages AUC (\times 10^7 cell)');
    ylabel('Death time (days)');
    set(gca, 'FontSize', fontSize, 'FontName', 'Arial');

    % ----- Subplot 3: M3 peak time (group mean) vs median survival time -----
    subplot(2, 2, 3);
    hold on; grid on; box on;
    for i = 1:n_mice
        scatter(M3_mean(i), median_times(i), markerSize_group, ...
                'MarkerEdgeColor', [1 1 1], ...
                'MarkerFaceColor', colors{i}, 'LineWidth', 1.5);
    end
    p = polyfit(M3_mean, median_times, 1);
    plot(M3_mean, polyval(p, M3_mean), '-', 'Color', [0 0 0], 'LineWidth', 1.5);
    [R_mat, P_mat] = corrcoef(M3_mean, median_times);
    R_val = R_mat(1,2); P_val = P_mat(1,2);
    if P_val < 0.001; p_text = 'p < 0.001';
    elseif P_val < 0.01; p_text = sprintf('p = %.2f', P_val);
    else p_text = sprintf('p = %.2f', P_val); end
    text(0.1, 0.8, sprintf('R = %.2f\n%s', R_val, p_text), ...
         'Color', [0 0 0], 'FontSize', fontSize+2, 'Units', 'normalized');
    legend(mouseNames, 'Location', 'southeast', 'NumColumns', 1, 'FontSize', fontSize-3);
    title('Group');
    xlim([7, 12]);
    xlabel('Peak time of M3-type macrophages (days)');
    ylabel('M-OS (days)');
    set(gca, 'FontSize', fontSize, 'FontName', 'Arial');

    % ----- Subplot 4: M3 peak time (individual) vs death time -----
    subplot(2, 2, 4);
    hold on; grid on; box on;
    x_all = []; y_all = [];
    for i = 1:n_mice
        x = M3_peak{i};      % already scaled to days
        y = Death((i-1)*n_samples_per_mouse+1 : i*n_samples_per_mouse);
        scatter(x, y, markerSize_indiv, ...
                'MarkerEdgeColor', [1 1 1], ...
                'MarkerFaceColor', colors{i});
        x_all = [x_all; x];
        y_all = [y_all; y];
    end
    p = polyfit(x_all, y_all, 1);
    plot(x_all, polyval(p, x_all), '-', 'Color', [0 0 0], 'LineWidth', lineWidth);
    [R_mat, P_mat] = corrcoef(x_all, y_all);
    R_val = R_mat(1,2); P_val = P_mat(1,2);
    if P_val < 0.001; p_text = 'p < 0.001';
    elseif P_val < 0.01; p_text = sprintf('p = %.3f', P_val);
    else p_text = sprintf('p = %.2f', P_val); end
    text(0.7, 0.2, sprintf('R = %.2f\n%s', R_val, p_text), ...
         'Color', [0 0 0], 'FontSize', fontSize+2, 'Units', 'normalized');
    xlabel('Peak time of M3-type macrophages (days)');
    ylabel('Death time (days)');
    title('Individual');
    ylim([21, 30]); xlim([5, 25]);
    set(gca, 'FontSize', fontSize, 'FontName', 'Arial');

    % Save second figure
    set(gcf, 'Unit', 'centimeters', 'Position', [22, 10, 26, 20]);
    print('Figure/Fig10BCDE', '-dpng', '-r200');

end