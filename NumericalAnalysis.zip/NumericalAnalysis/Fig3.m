function Fig3()
% FIG3 Plots total-order sensitivity indices for four model outputs.
%   This function loads sensitivity analysis results (Si_C, STi_C, etc.)
%   from the 'Data' folder and creates a 1x4 tiled figure showing the
%   total-order indices of all model parameters for tumor cells, M1, M2,
%   and M3 macrophages over time.
%
%   The figure is saved as 'Figure/Fig3.png' at 200 dpi.

    % --------------------------------------------------------------------
    % 1.  Parameter names (for legend)
    % --------------------------------------------------------------------
    param_names = {'\alpha','\it K','\delta','\it p','\eta','\kappa','\gamma',...
                   '\lambda','\it M_0','\beta_{13}','\beta_{32}','\it K_0','\it K_1',...
                   '\it K_2','\it d_1','\it d_{2}','\it d_3'};
    nParams = numel(param_names);   % 17 parameters

    % --------------------------------------------------------------------
    % 2.  Load sensitivity data
    % --------------------------------------------------------------------
    load('Data/STi_C.mat', 'STi_C');        % Total-order indices for C
    load('Data/STi_M1.mat', 'STi_M1');      % Total-order indices for M1
    load('Data/STi_M2.mat', 'STi_M2');      % Total-order indices for M2
    load('Data/STi_M3.mat', 'STi_M3');      % Total-order indices for M3

    % Time vector (days) – assumed to be 1:25 from the original code
    time = 1:25;

    % --------------------------------------------------------------------
    % 3.  Visual style definitions
    % --------------------------------------------------------------------
    Color = ColorMatrix();                  % Load predefined colour palette

    % Build a colour array for the 17 parameters (using two colour families)
    colors = [
        cell2mat(Color(2,1));   % alpha
        cell2mat(Color(2,4));   % K
        cell2mat(Color(2,6));   % delta
        cell2mat(Color(2,8));   % p
        cell2mat(Color(2,9));   % eta
        cell2mat(Color(2,10));  % kappa
        cell2mat(Color(2,11));  % gamma
        cell2mat(Color(2,13));  % lambda
        cell2mat(Color(2,14));  % M0
        cell2mat(Color(6,1));   % beta13
        cell2mat(Color(6,4));   % beta32
        cell2mat(Color(6,6));   % K0
        cell2mat(Color(6,8));   % K1
        cell2mat(Color(6,9));   % K2
        cell2mat(Color(6,10));  % d1
        cell2mat(Color(6,11));  % d2
        cell2mat(Color(6,13));  % d3
    ];

    % Markers and line styles for each parameter
    markers = {'o', 'o', 'o', 's', 's', 's', 'd', 'd', 'd', ...
               '^', '^', '^', 'p', 'p', 'p', 'v', 'v'};
    line_styles = {'-', '--', ':', '-.', '-', '--', ':', '-.', ...
                   '-', '--', ':', '-.', '-', '--', ':', '-.', '-'};

    % --------------------------------------------------------------------
    % 4.  Create tiled figure
    % --------------------------------------------------------------------
    figure('Position', [100, 100, 1400, 800]);

    % Subplot titles and corresponding data (total-order indices)
    subplot_titles = {'Tumor cells (C)', 'M1-type macrophages', ...
                      'M2-type macrophages', 'M3-type macrophages'};
    data_to_plot = {STi_C, STi_M1, STi_M2, STi_M3};

    % --------------------------------------------------------------------
    % 5.  Loop over the four outputs
    % --------------------------------------------------------------------
    for plot_idx = 1:4
        nexttile;                              % Create next subplot
        hold on; grid on; box on;

        % Store curve handles only for the first subplot (to create legend)
        if plot_idx == 1
            handles = gobjects(nParams, 1);    % Preallocate handle array
        end

        % Plot total-order indices for all parameters
        for i = 1:nParams
            h = plot(time, data_to_plot{plot_idx}(i, :), ...
                     'Color', colors(i, :), ...
                     'LineStyle', line_styles{i}, ...
                     'LineWidth', 1.8, ...
                     'Marker', markers{i}, ...
                     'MarkerSize', 7, ...
                     'MarkerEdgeColor', colors(i, :), ...
                     'MarkerFaceColor', colors(i, :));
            if plot_idx == 1
                handles(i) = h;                % Store handle for legend
            end
        end
        hold off;

        % Subplot formatting
        set(gca, 'FontSize', 14, 'LineWidth', 1, 'TickDir', 'in', 'Box', 'on');
        xlabel('Time (days)', 'FontSize', 14);
        ylabel('Total-order index', 'FontSize', 14);
        title(subplot_titles{plot_idx}, 'FontSize', 14);
        xlim([0, 25]);
    end

    % --------------------------------------------------------------------
    % 6.  Add legend to the first subplot only (to avoid clutter)
    % --------------------------------------------------------------------
    % Activate the first subplot before adding legend
    nexttile(1);
    legend(handles, param_names, 'Interpreter', 'tex', 'FontSize', 12, ...
           'NumColumns', 3, 'Location', 'best', 'Box', 'off');

    % --------------------------------------------------------------------
    % 7.  Save the figure
    % --------------------------------------------------------------------
    % Ensure the output directory exists
    set(gcf, 'Unit', 'centimeters', 'Position', [3, 10, 40, 18]);
    print('Figure/Fig3', '-dpng', '-r200');

end