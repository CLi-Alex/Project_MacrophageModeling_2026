function Matrix = ABC_Paras(i, m)
% ABC_PARAS Generates a matrix of parameter samples for ABC (Approximate Bayesian Computation).
%   This function creates an 8-by-m matrix where each row corresponds to a
%   specific model parameter, and each column represents one independent
%   parameter set drawn from predefined uniform distributions. The random
%   number generator is seeded with the input i to ensure reproducibility.
%
%   Inputs:
%       i : Integer seed used to initialize the random number generator (rng).
%       m : Number of parameter sets (i.e., number of columns in the output).
%
%   Output:
%       Matrix : [8 x m] matrix containing sampled parameter values.
%                Rows are organized as follows:
%                1: alpha   (rate constant)
%                2: K       (carrying capacity)
%                3: M0      (initial condition for a state variable)
%                4: kappa   (transition rate)
%                5: beta13  (interaction coefficient)
%                6: beta32  (interaction coefficient)
%                7: eta     (kill parameter)
%                8: p       (probability or fraction)

% Pre-allocate output matrix (8 rows, m columns)
Matrix = zeros(8, m);

% Set the random seed for reproducible sampling
rng(i);

% Row 1: Alpha – uniform distribution over [0.38, 0.46]
Matrix(1,:) = 0.38 + (0.46 - 0.38) * rand(1, m); % Alpha

% Row 2: K – uniform distribution over [2.17e8, 5e8]
Matrix(2,:) = 2.17e8 + (5e8 - 2.17e8) * rand(1, m); % K

% Row 3: M0 – uniform distribution over [1e5, 1e6]
Matrix(3,:) = 1e5 + (1e6 - 1e5) * rand(1, m); % M0

% Row 4: kappa – uniform distribution over [0, 1]
Matrix(4,:) = 0 + (1 - 0) * rand(1, m); % Kappa

% Row 5: beta13 – uniform distribution over [0, 1]
Matrix(5,:) = 0 + (1 - 0) * rand(1, m); % Beta_13

% Row 6: beta32 – uniform distribution over [0, 1]
Matrix(6,:) = 0 + (1 - 0) * rand(1, m); % Beta_32

% Row 7: eta – uniform distribution over [1e-8, 3e-8]
Matrix(7,:) = 1e-8 + (3e-8 - 1e-8) * rand(1, m); % Eta

% Row 8: p – uniform distribution over [0, 1]
Matrix(8,:) = 0 + (1 - 0) * rand(1, m); % P

end