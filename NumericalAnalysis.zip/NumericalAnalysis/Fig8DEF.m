function Fig8DEF()
% FIG8DEF Plots relationship between M3 peak time and tumor AUC.
%   This function loads ABC posterior results for 8 mice, computes the area
%   under the curve (AUC) for tumor volume, and determines the peak time
%   of M3 macrophages (time of maximum M3 count). It then generates three
%   subplots:
%       1) Kernel density estimates of M3 peak time distributions.
%       2) Group‑level scatter plot (mean ± error) with linear regression.
%       3) Individual‑level scatter plot (all posterior samples) with regression.
%   The figure is saved as 'Figure/Fig8DEF.png' at 200 dpi.

    % ====================================================================
    % 1. Load ABC posterior data
    % ====================================================================
    Q = 2501;   % Number of time points (0-25 days, dt=0.01)

    % Load 3D arrays: [Num × time × mouse]
    T_data = cell2mat(struct2cell(load('./Data/Tumor.mat')));   % Tumor cell counts
    M3_data = cell2mat(struct2cell(load('./Data/M3.mat')));     % M3 macrophage counts

    % Extract time series for each mouse (first Q time points)
    T = cell(8,1);
    M3 = cell(8,1);
    for i = 1:8
        T{i}  = T_data(:, 1:Q, i);
        M3{i} = M3_data(:, 1:Q, i);
    end

    % ====================================================================
    % 2. Compute tumor AUC and M3 peak time for each mouse
    % ====================================================================
    time = 0:0.01:25;          % Time vector (days)
    T_auc = cell(8,1);         % Tumor AUC (cell count · days)
    peak_idx = cell(8,1);      % Peak time index (1‑based) for M3

    for i = 1:8
        % Tumor AUC (trapezoidal integration)
        T_auc{i} = trapz(time, T{i}, 2);          % [Num × 1]

        % M3 peak time: find column index of maximum M3 count for each parameter set
        [~, peak_idx{i}] = max(M3{i}, [], 2);     % [Num × 1] indices (1‑based)
    end

    % Scaling factors for plotting
    scale1 = 0.01;   % Convert time index to days (since dt = 0.01, index = time/0.01 + 1)
    scale2 = 1e-9;   % Tumor AUC → ×10^9 mm³ (original code uses this scaling, no volume conversion)

    % ====================================================================
    % 3. Kernel density estimation for M3 peak time distributions
    % ====================================================================
    xi = cell(8,1);   % x‑coordinates of density estimate (days)
    f = cell(8,1);    % density values
    for i = 1:8
        [f{i}, xi{i}] = ksdensity(peak_idx{i} .* scale1);
    end

    % ====================================================================
    % 4. Visual parameters and colour palette
    % ====================================================================
    Color = ColorMatrix();
    lineWidth = 2;
    fontSize = 14;
    markerSize = 40;          % Base marker size (will be increased for group plot)

    % Colours for each mouse (from ColorMatrix)
    colors = {cell2mat(Color(3,9));  cell2mat(Color(3,10)); cell2mat(Color(3,1));
              cell2mat(Color(5,1));  cell2mat(Color(7,1));  cell2mat(Color(3,11));
              cell2mat(Color(3,13)); cell2mat(Color(5,13))};
    mouseNames = {'Mouse 1', 'Mouse 2', 'Mouse 3', 'Mouse 4', ...
                  'Mouse 5', 'Mouse 6', 'Mouse 7', 'Mouse 8'};

    % ====================================================================
    % 5. Create figure with 1×3 subplots
    % ====================================================================
    figure();

    % --------------------------------------------------------------------
    % Subplot 1: Density curves of M3 peak time
    % --------------------------------------------------------------------
    subplot(1,3,1);
    hold on; grid on; box on;
    for i = 1:8
        plot(xi{i}, f{i}, 'LineWidth', lineWidth, 'Color', colors{i});
    end
    legend(mouseNames, 'Location', 'northeast', 'NumColumns', 2, 'FontSize', fontSize-2);
    xlabel('Peak time of M3-type macrophages (days)');
    ylabel('Probability density');
    title('Distribution curve');
    set(gca, 'FontSize', fontSize, 'FontName', 'Arial');

    % --------------------------------------------------------------------
    % Subplot 2: Group‑level scatter (mean ± SD) and linear regression
    % --------------------------------------------------------------------
    % Compute mean values for each mouse
    T_mean = zeros(8,1);
    peak_mean = zeros(8,1);
    for i = 1:8
        T_mean(i) = mean(T_auc{i}) * scale2;
        peak_mean(i) = mean(peak_idx{i}) * scale1;
    end

    subplot(1,3,2);
    hold on; grid on; box on;
    % Plot group means as scatter points
    for i = 1:8
        scatter(peak_mean(i), T_mean(i), markerSize+100, ...
                'MarkerEdgeColor', [1 1 1], ...
                'MarkerFaceColor', colors{i}, ...
                'LineWidth', 1.5);
    end
    % Linear regression on group means
    p = polyfit(peak_mean, T_mean, 1);
    y_fit = polyval(p, peak_mean);
    plot(peak_mean, y_fit, '-', 'Color', [0 0 0], 'LineWidth', 1.5);
    [R, P] = corrcoef(peak_mean, T_mean);
    R_val = R(1,2);
    P_val = P(1,2);
    if P_val < 0.001
        p_text = 'p < 0.001';
    elseif P_val < 0.01
        p_text = sprintf('p = %.3f', P_val);
    else
        p_text = sprintf('p = %.2f', P_val);
    end
    text(0.1, 0.2, sprintf('R = %.2f\n%s', R_val, p_text), ...
         'Color', [0 0 0], 'FontSize', fontSize+2, 'Units', 'normalized');
    xlim([7 11.5]); ylim([1.25 3]);
    xlabel('Peak time of M3-type macrophages (days)');
    ylabel('Tumor AUC (\times 10^9 cells)');
    legend(mouseNames, 'Location', 'northeast', 'NumColumns', 2, 'FontSize', fontSize-2);
    title('Group');
    set(gca, 'FontSize', fontSize, 'FontName', 'Arial');

    % --------------------------------------------------------------------
    % Subplot 3: Individual‑level scatter (all samples) and linear regression
    % --------------------------------------------------------------------
    % Concatenate all samples (scaled) for regression
    peak_all = [];
    T_all = [];
    for i = 1:8
        peak_all = [peak_all; peak_idx{i} * scale1];
        T_all = [T_all; T_auc{i} * scale2];
    end

    subplot(1,3,3);
    hold on; grid on; box on;
    % Plot individual points (colour‑coded by mouse)
    for i = 1:8
        x = peak_idx{i} * scale1;
        y = T_auc{i} * scale2;
        scatter(x, y, markerSize, ...
                'MarkerEdgeColor', [1 1 1], ...
                'MarkerFaceColor', colors{i});
    end
    % Linear regression on all points
    p_all = polyfit(peak_all, T_all, 1);
    y_fit_all = polyval(p_all, peak_all);
    plot(peak_all, y_fit_all, '-', 'Color', [0 0 0], 'LineWidth', 1.5);
    [R_all, P_all] = corrcoef(peak_all, T_all);
    R_val_all = R_all(1,2);
    P_val_all = P_all(1,2);
    if P_val_all < 0.001
        p_text_all = 'p < 0.001';
    elseif P_val_all < 0.01
        p_text_all = sprintf('p = %.3f', P_val_all);
    else
        p_text_all = sprintf('p = %.2f', P_val_all);
    end
    text(0.7, 0.8, sprintf('R = %.2f\n%s', R_val_all, p_text_all), ...
         'Color', [0 0 0], 'FontSize', fontSize+2, 'Units', 'normalized');
    xlabel('Peak time of M3-type macrophages (days)');
    ylabel('Tumor AUC (\times 10^9 cells)');
    title('Individual');
    ylim([1.2 3.5]);   % xlim is automatically set from data, but original code didn't set xlim; we omit to match.
    set(gca, 'FontSize', fontSize, 'FontName', 'Arial');

    % ====================================================================
    % 6. Save the figure
    % ====================================================================
    set(gcf, 'Unit', 'centimeters', 'Position', [3, 10, 45, 10]);
    print('Figure/Fig8DEF', '-dpng', '-r200');

end