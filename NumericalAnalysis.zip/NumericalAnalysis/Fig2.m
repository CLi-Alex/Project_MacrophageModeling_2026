function Fig2(t, C, M1, M2, M3)
% FIG2 Plots simulation results of the tumor‑macrophage model.
%   This function creates a three‑panel figure showing:
%       1) Tumor volume over time compared to experimental data.
%       2) Absolute numbers of M1, M2, and M3 macrophages.
%       3) Relative proportions (percentages) of macrophage subtypes.
%
%   Inputs:
%       t  : Time vector (days) – must be uniformly spaced.
%       C  : Tumor cell population over time.
%       M1 : M1 macrophage population over time.
%       M2 : M2 macrophage population over time.
%       M3 : M3 macrophage population over time.

    % ---------------------------------------------------------------------
    % 1.  Create figure and load colour palette
    % ---------------------------------------------------------------------
    figure('Position', [100, 100, 1200, 800]);   % Set figure size and position
    Color = ColorMatrix();                       % Predefined colour palette

    % ---------------------------------------------------------------------
    % 2.  Experimental data (time points in days, mean tumor volumes in mm³)
    % ---------------------------------------------------------------------
    x = [8, 11, 13, 15, 18, 20, 23];             % Experimental time points
    y = [59.6775, 197.81, 343.03625, 585.6325, ...
         1066.7275, 1478.9875, 1907.08429];      % Mean tumor volumes (mm³)

    % ---------------------------------------------------------------------
    % 3.  Convert model tumor cell count to volume (mm³)
    % ---------------------------------------------------------------------
    V = 6.95e-9 .* C;                            % Conversion factor: 6.95e-9 mm³/cell

    % ---------------------------------------------------------------------
    % 4.  Compute R² between experimental data and model prediction
    % ---------------------------------------------------------------------
    R2 = Method_R2(y, V(x.*100) * 1e3);

    % ---------------------------------------------------------------------
    % 5.  Compute macrophage subtype proportions (as fractions)
    % ---------------------------------------------------------------------
    MR1 = M1 ./ (M1 + M2 + M3);   % Fraction of M1
    MR2 = M2 ./ (M1 + M2 + M3);   % Fraction of M2
    MR3 = M3 ./ (M1 + M2 + M3);   % Fraction of M3

    % ---------------------------------------------------------------------
    % 6.  Define common visual parameters
    % ---------------------------------------------------------------------
    LineWidth  = 2;               % Line width for plots
    MarkerSize = 10;              % Marker size for data points

    % ---------------------------------------------------------------------
    % 7.  Panel 1: Tumor volume vs. time (single curve + scatter)
    % ---------------------------------------------------------------------
    subplot(1, 3, 1);
    hold on; grid on; box on;

    % Model prediction (tumor volume in mm³)
    plot(t, V, 'r-', 'LineWidth', 2.5);

    % Experimental data (converted to ×10³ mm³ for y‑axis)
    scatter(x, y * 1e-3, 85, 'o', 'MarkerFaceColor', 'r');

    % Display R² value inside the plot
    text(0.1, 0.6, ['R^2=', num2str(R2, '%.3g')], ...
         'FontSize', 16, 'FontWeight', 'bold', 'Units', 'normalized');

    xlabel('Time (days)');
    ylabel('Tumor volume (\times 10^3 mm^3)');
    legend('Model simulation', 'Mean experimental data', ...
           'Location', 'northwest', 'FontSize', 14);

    set(gca, 'FontSize', 12, 'FontName', 'Arial');
    xlim([0, 25]);

    % ---------------------------------------------------------------------
    % 8.  Panel 2: Absolute macrophage counts (three curves)
    % ---------------------------------------------------------------------
    subplot(1, 3, 2);
    hold on; grid on; box on;

    % M1 macrophages (blue circles)
    plot(t, M1, '-o', 'Color', 'b', 'LineWidth', LineWidth, ...
         'MarkerIndices', 1:250:length(t), 'MarkerSize', MarkerSize, ...
         'MarkerFaceColor', 'b', 'MarkerEdgeColor', 'w');

    % M2 macrophages (red triangles)
    plot(t, M2, '-^', 'Color', 'r', 'LineWidth', LineWidth, ...
         'MarkerIndices', 1:250:length(t), 'MarkerSize', MarkerSize, ...
         'MarkerFaceColor', 'r', 'MarkerEdgeColor', 'w');

    % M3 macrophages (magenta‑purple squares)
    plot(t, M3, '-s', 'Color', cell2mat(Color(3,13)), 'LineWidth', LineWidth, ...
         'MarkerIndices', 1:200:length(t), 'MarkerSize', MarkerSize, ...
         'MarkerFaceColor', cell2mat(Color(3,13)), 'MarkerEdgeColor', 'w');

    xlabel('Time (days)');
    ylabel('Macrophages (cells)');
    legend('M1-type macrophages', 'M2-type macrophages', 'M3-type macrophages', ...
           'Location', 'northeast', 'FontSize', 12);

    set(gca, 'FontSize', 12, 'FontName', 'Arial');
    ylim([0, 5e6]);
    xlim([0, 25]);

    % ---------------------------------------------------------------------
    % 9.  Panel 3: Macrophage proportions (percentages)
    % ---------------------------------------------------------------------
    subplot(1, 3, 3);
    hold on; grid on; box on;

    % M1 percentage
    plot(t, MR1, '-o', 'Color', 'b', 'LineWidth', LineWidth, ...
         'MarkerIndices', 1:250:length(t), 'MarkerSize', MarkerSize, ...
         'MarkerFaceColor', 'b', 'MarkerEdgeColor', 'w');

    % M2 percentage
    plot(t, MR2, '-^', 'Color', 'r', 'LineWidth', LineWidth, ...
         'MarkerIndices', 1:250:length(t), 'MarkerSize', MarkerSize, ...
         'MarkerFaceColor', 'r', 'MarkerEdgeColor', 'w');

    % M3 percentage
    plot(t, MR3, '-s', 'Color', cell2mat(Color(3,13)), 'LineWidth', LineWidth, ...
         'MarkerIndices', 1:200:length(t), 'MarkerSize', MarkerSize, ...
         'MarkerFaceColor', cell2mat(Color(3,13)), 'MarkerEdgeColor', 'w');

    xlabel('Time (days)');
    ylabel('% Macrophages');
    set(gca, 'FontSize', 12, 'FontName', 'Arial');
    xlim([0, 25]);

    % ---------------------------------------------------------------------
    % 10. Save the figure to a PNG file
    % ---------------------------------------------------------------------
    set(gcf, 'Unit', 'centimeters', 'Position', [3, 10, 45, 8]);
    print('-dpng', '-r200', 'Figure/Fig2.png');

end