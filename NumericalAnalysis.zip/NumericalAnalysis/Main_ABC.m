function Main_ABC()
% MAIN_ABC Performs Approximate Bayesian Computation (ABC) for model calibration.
%   This function loads experimental data, samples parameter sets from prior
%   distributions, runs the tumor-macrophage model for each parameter set,
%   evaluates the goodness-of-fit using R², and retains the top parameter
%   sets that exceed a threshold (RR). The results are saved for each of the
%   8 experimental datasets.

    % -----------------------------------------------------------------
    % 1. Set acceptance threshold for R²
    % -----------------------------------------------------------------
    RR = 0.5;   % Minimum R² value required to accept a parameter set

    % -----------------------------------------------------------------
    % 2. Load experimental data
    % -----------------------------------------------------------------
    % Data is organized in 16 rows (2 rows per dataset × 8 datasets):
    %   Odd rows: time points (days)
    %   Even rows: corresponding tumor volume measurements (mm³)
    % Some datasets have missing values (NaN) at later time points.
    Data = [8 11 13 15 18 20 23; 86 268.02 430.35 670.93 1103.47 1556.73 1732.68;
            8 11 13 15 18 20 23; 74.66 284.71 430.71 619.76 1033.08 1350.51 1705.42;
            8 11 13 15 18 20 23; 72 200.29 326.36 610.41 1267.32 1646 2645.34;
            8 11 13 15 18 20 23; 71.54 195.76 351.1 680.19 1171.53 1716.05 2412.35;
            8 11 13 15 18 20 NaN; 62 211.76 454.96 840.17 1960.9 2388.14 NaN;
            8 11 13 15 18 20 23; 47.7 190.33 371.4 608.32 860.8 1265.47 1807.26;
            8 11 13 15 18 20 23; 39.64 145.12 214.51 340.28 540.06 893.15 1340.64;
            8 11 13 15 18 20 23; 23.88 86.49 164.9 315 596.66 1015.85 1705.9];

    % -----------------------------------------------------------------
    % 3. ABC settings
    % -----------------------------------------------------------------
    m = 1500;       % Number of parameter samples per dataset (prior draws)
    mm = 3101;      % Number of time points in model output (full simulation)
    Num = 100;      % Number of top parameter sets to retain per dataset

    % Preallocate storage for results
    Matrix = zeros(8, Num, 8);      % Selected parameter sets (8 params × Num × 8 datasets)
    R = zeros(8, Num);              % R² values for each retained parameter set
    W = zeros(8, Num);              % Acceptance indicator (1 if R² > RR, else 0)

    % Storage for full model trajectories (for accepted sets)
    Tumor_prior = zeros(m, mm, 8);  % All prior tumor trajectories (m samples × mm time points)
    Tumor = zeros(Num, mm, 8);      % Retained tumor trajectories (top Num sets)
    M1_prior = zeros(m, mm, 8);     % Prior M1 trajectories
    M1 = zeros(Num, mm, 8);         % Retained M1 trajectories
    M2_prior = zeros(m, mm, 8);     % Prior M2 trajectories
    M2 = zeros(Num, mm, 8);         % Retained M2 trajectories
    M3_prior = zeros(m, mm, 8);     % Prior M3 trajectories
    M3 = zeros(Num, mm, 8);         % Retained M3 trajectories

    % -----------------------------------------------------------------
    % 4. Loop over the 8 experimental datasets
    % -----------------------------------------------------------------
    for k = 1:8
        % Sample m parameter sets from the prior distributions for this dataset
        Matrix_ABC = ABC_Paras(k, m);

        % Initialize vectors for R² and acceptance flag for this dataset
        R_ABC = zeros(1, m);
        W_ABC = zeros(1, m);

        % -----------------------------------------------------------------
        % 4a. Evaluate each parameter set against the experimental data
        % -----------------------------------------------------------------
        for j = 1:m
            % Extract parameter set
            M = Matrix_ABC(:, j);

            % Run the model (Euler integration) for these parameters
            Y = ABC_Model(M);       % Y: [4 × mm] state trajectories

            % Retrieve experimental data for this dataset (k)
            % For dataset 5 (k=5), there are only 6 time points (last is NaN)
            if k == 5
                D = Data(2*k-1:2*k, 1:6);
            else
                D = Data(2*k-1:2*k, 1:7);
            end

            % Experimental time points (convert days to indices)
            % Times are given in days; model simulation uses daily time steps,
            % so time point t corresponds to index t+1.
            T = 1 + 100 .* D(1, :);   % Convert days to indices (time step = 0.01 day)

            % Experimental tumor volumes (mm³)
            P = D(2, :);

            % Model-predicted tumor volumes at the corresponding time points
            % Conversion factor 6.95e-6 translates model cell count to volume?
            Q = Y(1, T) .* 6.95e-6;

            % Compute R² between experimental and model-predicted volumes
            R_ABC(j) = Method_R2(P, Q);

            % Accept parameter set if R² exceeds threshold RR
            if R_ABC(j) > RR
                Indicator = 1;
            else
                Indicator = 0;
            end
            W_ABC(1, j) = Indicator;

            % Store full model trajectories for this sample (for later retrieval)
            Tumor_prior(j, :, k) = Y(1, :);   % Tumor cells
            M1_prior(j, :, k)    = Y(2, :);   % M1 macrophages
            M2_prior(j, :, k)    = Y(3, :);   % M2 macrophages
            M3_prior(j, :, k)    = Y(4, :);   % M3 macrophages
        end

        % -----------------------------------------------------------------
        % 4b. Select the top Num parameter sets based on R²
        % -----------------------------------------------------------------
        [~, topNum_idx] = maxk(R_ABC, Num);   % Indices of highest R² values

        % Store the selected parameter sets and their R² values
        Matrix(:, :, k) = Matrix_ABC(:, topNum_idx);
        R(k, :) = R_ABC(:, topNum_idx);
        W(k, :) = W_ABC(:, topNum_idx);

        % Store the corresponding full model trajectories for the top sets
        Tumor(:,:,k) = Tumor_prior(topNum_idx, :, k);
        M1(:,:,k)    = M1_prior(topNum_idx, :, k);
        M2(:,:,k)    = M2_prior(topNum_idx, :, k);
        M3(:,:,k)    = M3_prior(topNum_idx, :, k);
    end

    % -----------------------------------------------------------------
    % 5. Save results to .mat files in the 'Data' folder
    % -----------------------------------------------------------------
    save('Data/Matrix.mat', 'Matrix');
    save('Data/R.mat', 'R');
    save('Data/W.mat', 'W');
    save('Data/Tumor.mat', 'Tumor');
    save('Data/M1.mat', 'M1');
    save('Data/M2.mat', 'M2');
    save('Data/M3.mat', 'M3');

end