function R2 = Method_R2(observed, simulated)
% METHOD_R2 Calculates the coefficient of determination (R²) between observed and simulated data.
%   This function computes R² = 1 - RSS/TSS, where:
%       RSS = Residual Sum of Squares (sum of squared differences)
%       TSS = Total Sum of Squares (sum of squared differences from the mean of observed)
%   R² measures the proportion of variance in the observed data that is explained by the
%   simulated (model-predicted) data. Values close to 1 indicate a good fit.
%
%   Inputs:
%       observed   - Vector of experimental/observed data points.
%       simulated  - Vector of model-simulated data points (must be same length as observed).
%
%   Output:
%       R2         - Coefficient of determination (scalar). Can range from -∞ to 1.

    % Ensure input vectors are column vectors for consistent indexing
    observed = observed(:);
    simulated = simulated(:);

    % Residual Sum of Squares: sum of squared differences between observed and simulated
    RSS = sum((observed - simulated).^2);

    % Total Sum of Squares: sum of squared differences between observed and its mean
    TSS = sum((observed - mean(observed)).^2);

    % Coefficient of determination
    R2 = 1 - (RSS / TSS);

end