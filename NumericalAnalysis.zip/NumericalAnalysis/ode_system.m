function dydt = ode_system(t, y, params)
% ODE_SYSTEM Defines the system of ordinary differential equations for the tumor-macrophage interaction model.
%   This function computes the time derivatives of four state variables:
%       C  : tumor cell population
%       M1 : M1 macrophage population (pro-inflammatory, anti-tumor)
%       M2 : M2 macrophage population (anti-inflammatory, pro-tumor)
%       M3 : M3 macrophage population (intermediate/plastic phenotype)
%   The model incorporates tumor growth, macrophage polarization, and interactions.
%
%   Inputs:
%       t       - Current time (scalar; not directly used but required for ODE solver interface).
%       y       - State vector [C; M1; M2; M3] at current time.
%       params  - Structure containing all model parameters.
%
%   Output:
%       dydt    - Time derivative vector [dC/dt; dM1/dt; dM2/dt; dM3/dt].

    % -----------------------------------------------------------------
    % 1. Extract state variables from input vector
    % -----------------------------------------------------------------
    C  = y(1);   % Tumor cells
    M1 = y(2);   % M1 macrophages
    M2 = y(3);   % M2 macrophages
    M3 = y(4);   % M3 macrophages

    % -----------------------------------------------------------------
    % 2. Hill functions (sigmoidal activation terms)
    % -----------------------------------------------------------------
    % Polarization of M2 macrophages induced by tumor cells
    hill_M2_polarization = C / (params.K0 + C);

    % Transition from M1 to M3 (M1 → M3) stimulated by tumor cells
    hill_M1_to_M3 = C / (params.K1 + C);

    % Transition from M3 to M2 (M3 → M2) stimulated by tumor cells
    hill_M3_to_M2 = C / (params.K2 + C);

    % -----------------------------------------------------------------
    % 3. Tumor cell dynamics (C)
    % -----------------------------------------------------------------
    % Growth term: logistic growth with carrying capacity K,
    % enhanced by pro-tumor macrophages (M2 + p*M3) where p is a fraction
    % (0 ≤ p ≤ 1) of M3 that contributes to tumor promotion.
    % Death term: tumor cell killing by anti-tumor macrophages (M1 + (1-p)*M3).
    dC_dt = params.alpha * (1 + params.delta * (M2 + params.p * M3)) * ...
            (1 - C/params.K) * C - params.eta * (M1 + (1 - params.p) * M3) * C;

    % -----------------------------------------------------------------
    % 4. M1 macrophage dynamics
    % -----------------------------------------------------------------
    % Recruitment from precursor pool (params.kappa * params.M0).
    % Loss due to polarization to M3 (params.beta13 * hill_M1_to_M3 * M1).
    % Gain from back‑polarization of M3 to M1 (params.beta31 * M3).
    % Natural death (params.d1 * M1).
    dM1_dt = params.kappa * params.M0 - params.beta13 * hill_M1_to_M3 * M1 + ...
             params.beta31 * M3 - params.d1 * M1;

    % -----------------------------------------------------------------
    % 5. M2 macrophage dynamics
    % -----------------------------------------------------------------
    % Recruitment from precursor pool, enhanced by tumor‑induced polarization
    % (params.gamma * (1 + params.lambda * hill_M2_polarization) * params.M0).
    % Gain from M3 → M2 transition (params.beta32 * hill_M3_to_M2 * M3).
    % Loss due to polarization to M3 (params.beta23 * M2).
    % Natural death (params.d2 * M2).
    dM2_dt = params.gamma * (1 + params.lambda * hill_M2_polarization) * params.M0 + ...
             params.beta32 * hill_M3_to_M2 * M3 - params.beta23 * M2 - params.d2 * M2;

    % -----------------------------------------------------------------
    % 6. M3 macrophage dynamics
    % -----------------------------------------------------------------
    % Gain from M1 → M3 transition (params.beta13 * hill_M1_to_M3 * M1).
    % Loss due to back‑polarization to M1 (params.beta31 * M3).
    % Loss due to polarization to M2 (params.beta32 * hill_M3_to_M2 * M3).
    % Gain from M2 → M3 transition (params.beta23 * M2).
    % Natural death (params.d3 * M3).
    dM3_dt = params.beta13 * hill_M1_to_M3 * M1 - params.beta31 * M3 - ...
             params.beta32 * hill_M3_to_M2 * M3 + params.beta23 * M2 - params.d3 * M3;

    % -----------------------------------------------------------------
    % 7. Assemble the derivative vector
    % -----------------------------------------------------------------
    dydt = [dC_dt; dM1_dt; dM2_dt; dM3_dt];

end