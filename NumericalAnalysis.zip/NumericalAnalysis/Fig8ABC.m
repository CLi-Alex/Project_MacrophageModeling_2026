function Fig8ABC()
% FIG8ABC Plots relationship between M1 macrophage AUC and tumor AUC.
%   This function loads ABC posterior results for 8 mice, computes the area
%   under the curve (AUC) for tumor volume and M1 macrophage counts, then
%   generates three subplots:
%       1) Kernel density estimates of M1 AUC distributions for each mouse.
%       2) Group‑level scatter plot (mean ± error) with linear regression.
%       3) Individual‑level scatter plot (all posterior samples) with regression.
%   The figure is saved as 'Figure/Fig8ABC.png' at 200 dpi.

    % ====================================================================
    % 1. Load ABC posterior data
    % ====================================================================
    Q = 2501;   % Number of time points (0-25 days, dt=0.01)

    % Load 3D arrays: [Num × time × mouse]
    T_data = cell2mat(struct2cell(load('./Data/Tumor.mat')));   % Tumor cell counts
    M1_data = cell2mat(struct2cell(load('./Data/M1.mat')));     % M1 macrophage counts

    % Extract time series for each mouse (first Q time points)
    T = cell(8,1);
    M1 = cell(8,1);
    for i = 1:8
        T{i}  = T_data(:, 1:Q, i);
        M1{i} = M1_data(:, 1:Q, i);
    end

    % ====================================================================
    % 2. Compute area under the curve (AUC) for each mouse and parameter set
    % ====================================================================
    time = 0:0.01:25;          % Time vector (days)
    T_auc = cell(8,1);         % Tumor AUC (cell count · days)
    M1_auc = cell(8,1);        % M1 AUC (cell count · days)

    for i = 1:8
        T_auc{i} = trapz(time, T{i}, 2);      % [Num × 1]
        M1_auc{i} = trapz(time, M1{i}, 2);    % [Num × 1]
    end

    % Scaling factors for plotting (to bring values into readable range)
    scale1 = 1e-7;   % M1 AUC → ×10^7 cells
    scale2 = 1e-9;   % Tumor AUC → ×10^9 mm³ (note: original code multiplies tumor cell AUC by 1e-9 without volume conversion; this matches the original figure)

    % ====================================================================
    % 3. Kernel density estimation for M1 AUC distributions
    % ====================================================================
    xi = cell(8,1);   % x‑coordinates of density estimate
    f = cell(8,1);    % density values
    for i = 1:8
        [f{i}, xi{i}] = ksdensity(M1_auc{i} .* scale1);
    end

    % ====================================================================
    % 4. Visual parameters and colour palette
    % ====================================================================
    Color = ColorMatrix();
    lineWidth = 2;
    fontSize = 14;
    markerSize = 40;          % Base marker size (will be increased for group plot)

    % Colours for each mouse (from ColorMatrix)
    colors = {cell2mat(Color(3,9));  cell2mat(Color(3,10)); cell2mat(Color(3,1));
              cell2mat(Color(5,1));  cell2mat(Color(7,1));  cell2mat(Color(3,11));
              cell2mat(Color(3,13)); cell2mat(Color(5,13))};
    mouseNames = {'Mouse 1', 'Mouse 2', 'Mouse 3', 'Mouse 4', ...
                  'Mouse 5', 'Mouse 6', 'Mouse 7', 'Mouse 8'};

    % ====================================================================
    % 5. Create figure with 1×3 subplots
    % ====================================================================
    figure();

    % --------------------------------------------------------------------
    % Subplot 1: Density curves of M1 AUC
    % --------------------------------------------------------------------
    subplot(1,3,1);
    hold on; grid on; box on;
    for i = 1:8
        plot(xi{i}, f{i}, 'LineWidth', lineWidth, 'Color', colors{i});
    end
    legend(mouseNames, 'Location', 'northeast', 'NumColumns', 2, 'FontSize', fontSize-2);
    xlabel('M1-type macrophages AUC (\times 10^7 cells)');
    ylabel('Probability density');
    title('Distribution curve');
    set(gca, 'FontSize', fontSize, 'FontName', 'Arial');

    % --------------------------------------------------------------------
    % Subplot 2: Group‑level scatter (mean ± SD) and linear regression
    % --------------------------------------------------------------------
    % Compute mean AUC for each mouse (scaled)
    T_mean = zeros(8,1);
    M1_mean = zeros(8,1);
    for i = 1:8
        T_mean(i) = mean(T_auc{i}) * scale2;
        M1_mean(i) = mean(M1_auc{i}) * scale1;
    end

    subplot(1,3,2);
    hold on; grid on; box on;
    % Plot group means as scatter points
    for i = 1:8
        scatter(M1_mean(i), T_mean(i), markerSize+100, ...
                'MarkerEdgeColor', [1 1 1], ...
                'MarkerFaceColor', colors{i}, ...
                'LineWidth', 1.5);
    end
    % Linear regression and R²/p‑value
    p = polyfit(M1_mean, T_mean, 1);
    y_fit = polyval(p, M1_mean);
    plot(M1_mean, y_fit, '-', 'Color', [0 0 0], 'LineWidth', 1.5);
    [R, P] = corrcoef(M1_mean, T_mean);
    R_val = R(1,2);
    P_val = P(1,2);
    % Format p‑value for display
    if P_val < 0.001
        p_text = 'p < 0.001';
    elseif P_val < 0.01
        p_text = sprintf('p = %.3f', P_val);
    else
        p_text = sprintf('p = %.2f', P_val);
    end
    text(0.1, 0.2, sprintf('R = %.2f\n%s', R_val, p_text), ...
         'Color', [0 0 0], 'FontSize', fontSize+2, 'Units', 'normalized');
    xlim([2.75 5.25]); ylim([1 3]);
    xlabel('M1-type macrophages AUC (\times 10^7 cells)');
    ylabel('Tumor AUC (\times 10^9 cells)');
    legend(mouseNames, 'Location', 'northeast', 'NumColumns', 2, 'FontSize', fontSize-2);
    title('Group');
    set(gca, 'FontSize', fontSize, 'FontName', 'Arial');

    % --------------------------------------------------------------------
    % Subplot 3: Individual‑level scatter (all samples) and linear regression
    % --------------------------------------------------------------------
    % Concatenate all samples (scaled) for regression
    x_all = [];
    y_all = [];
    for i = 1:8
        x_all = [x_all; M1_auc{i} * scale1];
        y_all = [y_all; T_auc{i} * scale2];
    end

    subplot(1,3,3);
    hold on; grid on; box on;
    % Plot individual points (colour‑coded by mouse)
    for i = 1:8
        x = M1_auc{i} * scale1;
        y = T_auc{i} * scale2;
        scatter(x, y, markerSize, ...
                'MarkerEdgeColor', [1 1 1], ...
                'MarkerFaceColor', colors{i});
    end
    % Linear regression on all points
    p_all = polyfit(x_all, y_all, 1);
    y_fit_all = polyval(p_all, x_all);
    plot(x_all, y_fit_all, '-', 'Color', [0 0 0], 'LineWidth', 1.5);
    [R_all, P_all] = corrcoef(x_all, y_all);
    R_val_all = R_all(1,2);
    P_val_all = P_all(1,2);
    if P_val_all < 0.001
        p_text_all = 'p < 0.001';
    elseif P_val_all < 0.01
        p_text_all = sprintf('p = %.3f', P_val_all);
    else
        p_text_all = sprintf('p = %.2f', P_val_all);
    end
    text(0.7, 0.8, sprintf('R = %.2f\n%s', R_val_all, p_text_all), ...
         'Color', [0 0 0], 'FontSize', fontSize+2, 'Units', 'normalized');
    xlabel('M1-type macrophages AUC (\times 10^7 cells)');
    ylabel('Tumor AUC (\times 10^9 cells)');
    title('Individual');
    xlim([1.5 13.5]); ylim([1.2 3.5]);
    set(gca, 'FontSize', fontSize, 'FontName', 'Arial');

    % ====================================================================
    % 6. Save the figure
    % ====================================================================
    set(gcf, 'Unit', 'centimeters', 'Position', [3, 10, 45, 10]);
    print('Figure/Fig8ABC', '-dpng', '-r200');

end