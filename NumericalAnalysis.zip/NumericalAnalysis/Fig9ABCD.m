function Fig9ABCD()
% FIG9ABCD Fits a threshold (Q) to survival data using PSO.
%   This function loads ABC posterior results, normalizes tumor cell counts
%   by the carrying capacity K, adds artificial noise, then uses Particle
%   Swarm Optimization (PSO) to find the optimal threshold Q that minimizes
%   the RMSE between the simulated and experimental survival curves.
%   It also generates a 4‑panel figure showing:
%       1) Survival curves (experimental vs. simulated)
%       2) PSO convergence curve
%       3) Individual death risk trajectories
%       4) Sensitivity analysis of Q
%   The optimized death times are saved to 'Data/death_times.mat'.

    % ====================================================================
    % 1. Experimental survival data
    % ====================================================================
    % Define experimental survival rate (%) as a step function.
    % The survival curve decreases at specific time points (20, 23, 26, 28 days).
    t_step = 0:0.01:31;
    Death = [100 * ones(1, length(0:0.01:20)), ...
             87.5 * ones(1, length(20.01:0.01:23)), ...
             62.5 * ones(1, length(23.01:0.01:26)), ...
             12.5 * ones(1, length(26.01:0.01:28)), ...
             0 * ones(1, length(28.01:0.01:31))];

    % ====================================================================
    % 2. Load ABC posterior data
    % ====================================================================
    % Matrix dimensions: [8 parameters × 100 samples × 8 mice]
    Matrix = cell2mat(struct2cell(load('./Data/Matrix.mat')));
    % Tumor data: [100 samples × 3101 time points × 8 mice]
    T = cell2mat(struct2cell(load('./Data/Tumor.mat')));

    % Normalized tumor cell count: divide by the carrying capacity K
    % K is the second row of Matrix (parameter index 2).
    T_norm_cell = cell(8, 1);
    for mouse = 1:8
        % Extract K values for this mouse (1 × 100 row vector)
        K_mouse = Matrix(2, :, mouse);               % 1 × 100
        % Normalize: each sample (row) divided by its own K
        % Convert K_mouse to column vector for proper broadcasting
        T_norm_cell{mouse} = T(:, :, mouse) ./ K_mouse(:);   % 100 × 3101
    end

    % Concatenate all mice (8 × 100 = 800 samples) into one matrix
    T_norm = vertcat(T_norm_cell{:});                % 800 × 3101

    % ====================================================================
    % 3. Add artificial noise (to simulate biological variability)
    % ====================================================================
    rng(1);          % For reproducibility
    noise_amplitude = 0.025;
    T_all = T_norm + noise_amplitude * randn(800, 3101);

    % ====================================================================
    % 4. PSO settings
    % ====================================================================
    pso_params = struct(...
        'n_particles', 20, ...   % Number of particles
        'max_iter',    20, ...   % Maximum iterations
        'w',           0.7, ...  % Inertia weight
        'c1',          2, ...    % Cognitive coefficient
        'c2',          2);       % Social coefficient
    Q_range = [0.9, 1];          % Search range for Q

    % ====================================================================
    % 5. Run PSO optimization
    % ====================================================================
    [Q_opt, best_fitness, history] = pso_optimize_Q(...
        T_all, Death, t_step, Q_range, pso_params);
    fprintf('Result: Q = %.4f, RMSE = %.4f\n', Q_opt, best_fitness);

    % ====================================================================
    % 6. Compute death times and survival curve for the optimal Q
    % ====================================================================
    death_times = calculate_death_times(T_all, t_step, Q_opt);
    simulated_survival = calculate_survival_curve(death_times, t_step);

    % ====================================================================
    % 7. Plot results
    % ====================================================================
    plot_results(t_step, Death, simulated_survival, death_times, ...
                 T_all, Q_opt, Q_range, history);

    % ====================================================================
    % 8. Save death times for later use
    % ====================================================================
    if ~exist('Data', 'dir')
        mkdir('Data');
    end
    save('Data/death_times.mat', 'death_times');

end

% ------------------------------------------------------------------------
% Helper function: calculate death times based on threshold Q
% ------------------------------------------------------------------------
function death_times = calculate_death_times(T_norm, Time, Q)
% CALCULATE_DEATH_TIMES Finds the first time each sample exceeds threshold Q.
%   Input:
%       T_norm : [n_samples × n_time] matrix of normalized tumor cell counts.
%       Time   : row vector of time points.
%       Q      : scalar threshold.
%   Output:
%       death_times : column vector of death times (days) for each sample.
%                     If never exceeds Q, death time is set to Time(end).
    n_samples = size(T_norm, 1);
    death_times = repmat(Time(end), n_samples, 1);

    for i = 1:n_samples
        idx = find(T_norm(i, :) > Q, 1);
        if ~isempty(idx)
            death_times(i) = Time(idx);
        end
    end
end

% ------------------------------------------------------------------------
% Helper function: compute survival curve from death times
% ------------------------------------------------------------------------
function survival_curve = calculate_survival_curve(death_times, Time)
% CALCULATE_SURVIVAL_CURVE Computes the percentage of survivors over time.
%   Input:
%       death_times : column vector of death times.
%       Time        : row vector of time points.
%   Output:
%       survival_curve : row vector of survival percentages.
    n_samples = length(death_times);
    survival_curve = zeros(1, length(Time));
    for t_idx = 1:length(Time)
        alive_count = sum(death_times > Time(t_idx));
        survival_curve(t_idx) = (alive_count / n_samples) * 100;
    end
end

% ------------------------------------------------------------------------
% Helper function: RMSE objective for PSO
% ------------------------------------------------------------------------
function rmse = objective_function(Q, T_norm, Death, Time)
% OBJECTIVE_FUNCTION Computes RMSE between experimental and simulated survival.
%   Input:
%       Q       : threshold candidate.
%       T_norm  : normalized tumor trajectories.
%       Death   : experimental survival curve (%).
%       Time    : time vector.
%   Output:
%       rmse    : root‑mean‑square error.
    death_times = calculate_death_times(T_norm, Time, Q);
    simulated_survival = calculate_survival_curve(death_times, Time);
    rmse = sqrt(mean((simulated_survival - Death).^2));
end

% ------------------------------------------------------------------------
% PSO optimization for Q
% ------------------------------------------------------------------------
function [Q_opt, best_fitness, history] = pso_optimize_Q(...
    T_norm, Death, Time, Q_range, params)
% PSO_OPTIMIZE_Q Performs Particle Swarm Optimization to find optimal Q.
%   Input:
%       T_norm    : normalized tumor trajectories.
%       Death     : experimental survival curve.
%       Time      : time vector.
%       Q_range   : [lower, upper] bound for Q.
%       params    : structure with fields:
%           n_particles, max_iter, w, c1, c2.
%   Output:
%       Q_opt        : optimal Q value.
%       best_fitness : best RMSE achieved.
%       history      : fitness value at each iteration.
    n_particles = params.n_particles;
    max_iter = params.max_iter;
    w = params.w;
    c1 = params.c1;
    c2 = params.c2;

    % Initialize particles
    particles.pos = Q_range(1) + rand(n_particles, 1) * (Q_range(2) - Q_range(1));
    particles.vel = zeros(n_particles, 1);
    particles.pbest = particles.pos;
    particles.pbest_fit = inf(n_particles, 1);

    % Global best
    gbest_fit = inf;
    gbest_pos = particles.pos(1);
    history = zeros(max_iter, 1);

    for iter = 1:max_iter
        % Linearly decreasing inertia weight
        w_current = w * (1 - 0.5 * iter / max_iter);

        % Evaluate all particles and update personal/global best
        for i = 1:n_particles
            fitness = objective_function(particles.pos(i), T_norm, Death, Time);
            if fitness < particles.pbest_fit(i)
                particles.pbest_fit(i) = fitness;
                particles.pbest(i) = particles.pos(i);
            end
            if fitness < gbest_fit
                gbest_fit = fitness;
                gbest_pos = particles.pos(i);
            end
        end

        % Update velocity and position
        for i = 1:n_particles
            r1 = rand();
            r2 = rand();
            particles.vel(i) = w_current * particles.vel(i) + ...
                c1 * r1 * (particles.pbest(i) - particles.pos(i)) + ...
                c2 * r2 * (gbest_pos - particles.pos(i));
            particles.pos(i) = particles.pos(i) + particles.vel(i);

            % Enforce bounds with reflection
            if particles.pos(i) < Q_range(1)
                particles.pos(i) = Q_range(1);
                particles.vel(i) = -0.5 * particles.vel(i);
            elseif particles.pos(i) > Q_range(2)
                particles.pos(i) = Q_range(2);
                particles.vel(i) = -0.5 * particles.vel(i);
            end
        end

        history(iter) = gbest_fit;
        if mod(iter, 5) == 0
            fprintf('iteration %3d: RMSE = %.4f, Q = %.4f\n', ...
                iter, gbest_fit, gbest_pos);
        end
    end

    Q_opt = gbest_pos;
    best_fitness = gbest_fit;
end

% ------------------------------------------------------------------------
% Plotting function
% ------------------------------------------------------------------------
function plot_results(Time, Death, simulated_survival, death_times, ...
    T_norm, Q_opt, Q_range, history)
% PLOT_RESULTS Creates the four‑panel figure.
    figure();
    Color = ColorMatrix();
    fontSize = 14;
    lineWidth = 2;
    markerSize = 9;

    % ------------------- Subplot 1: Survival curve -------------------
    subplot(1, 4, 1);
    hold on; grid on; box on;
    plot(Time, Death, 'r-', 'LineWidth', lineWidth);
    plot(Time, simulated_survival, 'b-.', 'LineWidth', lineWidth);
    scatter(median(death_times), 50, markerSize+100, ...
        'MarkerFaceColor', 'b', 'MarkerEdgeColor', [1 1 1]);
    text(15.75, 50, sprintf('M-OS = %.1f days', median(death_times)), ...
        'FontSize', fontSize, 'FontWeight', 'bold', 'Color', 'b');
    xlim([15, 30]);
    xlabel('Time (days)');
    ylabel('Survival rate (%)');
    title(sprintf('Survival curve (Q = %.4f)', Q_opt));
    legend_labels = {
        ['Experimental data' newline '         (n = 8)']
        ['Model simulation' newline '       (n = 800)']
    };
    legend(legend_labels, 'Location', 'southwest', 'FontSize', fontSize-3);
    set(gca, 'FontSize', fontSize, 'FontName', 'Arial');

    % ------------------- Subplot 2: PSO convergence -------------------
    subplot(1, 4, 2);
    hold on; grid on; box on;
    iter = 1:length(history);
    plot(iter, history, '-o', 'Color', cell2mat(Color(1,13)), ...
        'LineWidth', lineWidth, 'MarkerIndices', 1:1:length(history), ...
        'MarkerSize', markerSize, ...
        'MarkerFaceColor', cell2mat(Color(1,13)), ...
        'MarkerEdgeColor', [1 1 1]);
    xlim([1, 20]);
    xlabel('Iterations');
    ylabel('RMSE');
    title('PSO convergence curve');
    set(gca, 'FontSize', fontSize, 'FontName', 'Arial');

    % ------------------- Subplot 3: Individual death risk -------------
    subplot(1, 4, 3);
    hold on; grid on; box on;
    plot(Time, T_norm(1:800, :), 'LineWidth', lineWidth-1.75);
    yline(Q_opt, 'r:', 'LineWidth', lineWidth+1);
    text(5, 0.85, sprintf('Q = %.4f', Q_opt), 'FontSize', fontSize+2, ...
        'FontWeight', 'bold', 'Color', 'r');
    xlim([0, 30]);
    xlabel('Time (days)');
    ylabel('Death risk');
    title('Individual death risk');
    set(gca, 'FontSize', fontSize, 'FontName', 'Arial');

    % ------------------- Subplot 4: Sensitivity analysis -------------
    subplot(1, 4, 4);
    hold on; grid on; box on;
    Q_test = linspace(Q_range(1), Q_range(2), 15);
    rmse_test = zeros(size(Q_test));
    for i = 1:length(Q_test)
        death_times_tmp = calculate_death_times(T_norm, Time, Q_test(i));
        survival_tmp = calculate_survival_curve(death_times_tmp, Time);
        rmse_test(i) = sqrt(mean((survival_tmp - Death).^2));
    end
    plot(Q_test, rmse_test, '-o', 'Color', 'b', 'LineWidth', lineWidth, ...
        'MarkerIndices', 1:1:length(Q_test), 'MarkerSize', markerSize, ...
        'MarkerFaceColor', 'b', 'MarkerEdgeColor', [1 1 1]);
    xline(Q_opt, 'r:', 'LineWidth', lineWidth+1);
    text(0.92, 7.25, sprintf('Q = %.4f', Q_opt), 'FontSize', fontSize+2, ...
        'FontWeight', 'bold', 'Color', 'r');
    ylim([6, 14]);
    xlabel('Threshold Q');
    ylabel('RMSE');
    title('Q value sensitivity analysis');
    set(gca, 'FontSize', fontSize, 'FontName', 'Arial');

    % ------------------- Save figure -------------------
    set(gcf, 'Unit', 'centimeters', 'Position', [3, 10, 50, 9]);
    print('Figure/Fig9ABCD', '-dpng', '-r200');

end