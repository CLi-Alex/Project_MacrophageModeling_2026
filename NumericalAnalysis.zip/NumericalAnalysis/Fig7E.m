function Fig7E()
% FIG7E Plots parameter posterior distributions grouped by mouse clusters.
%   This function loads the ABC parameter matrix (8 parameters × Num × 8 mice),
%   groups the 8 mice into 3 clusters (defined by group_def), computes the mean
%   and standard deviation for each parameter within each group, and generates
%   a 4×2 subplot (8 parameters) of bar charts with error bars.
%   The figure is saved as 'Figure/Fig7E.png' at 200 dpi.

    % ====================================================================
    % 1. Load ABC parameter matrix
    % ====================================================================
    % Matrix dimensions: [8 parameters × Num samples × 8 mice]
    Matrix = cell2mat(struct2cell(load('./Data/Matrix.mat')));

    % ====================================================================
    % 2. Define mouse grouping (based on original figure)
    % ====================================================================
    % Group I: mice 3,4,5
    % Group II: mice 1,2,6
    % Group III: mice 7,8
    group_def = {[3, 4, 5], [1, 2, 6], [7, 8]};
    n_groups = length(group_def);

    % Parameter names (used for titles and axis limits)
    param_names = {'alpha', 'K', 'M0', 'Kappa', 'Beta13', 'Beta32', 'Eta', 'P'};
    n_params = length(param_names);

    % ====================================================================
    % 3. Compute mean and standard deviation per parameter per group
    % ====================================================================
    means_all = zeros(n_params, n_groups);
    stds_all = zeros(n_params, n_groups);

    for param_idx = 1:n_params
        for group_idx = 1:n_groups
            m_indices = group_def{group_idx};   % Mouse indices in this group
            % Collect all samples for this parameter from all mice in the group
            group_data = [];
            for m_idx = m_indices
                % Matrix(param, :, mouse) → row vector of all samples for that mouse
                current_data = Matrix(param_idx, :, m_idx);
                group_data = [group_data, current_data];
            end
            means_all(param_idx, group_idx) = mean(group_data);
            stds_all(param_idx, group_idx) = std(group_data);
        end
    end

    % ====================================================================
    % 4. Visual parameters and figure setup
    % ====================================================================
    figure('Position', [100, 100, 1600, 800]);
    Color = ColorMatrix();
    fontSize = 16;

    % Bar edge colours for the three groups (from ColorMatrix)
    bar_colors = [cell2mat(Color(1,1));   % Group I (red)
                  cell2mat(Color(1,11));  % Group II (greenish)
                  cell2mat(Color(1,13))]; % Group III (purple)

    % Y-axis limits for each parameter (matching original figure)
    ylimits = [
        0.37 0.47;      % alpha
        2e8 5e8;        % K
        0 1e6;          % M0
        0 1;            % Kappa
        0 1;            % Beta13
        0 1;            % Beta32
        0 3.6e-8;       % Eta
        0 1             % P
    ];

    % Parameter titles (TeX format for subplot titles)
    titles = {'\alpha', 'K', 'M_0', '\kappa', '\beta_{13}', '\beta_{32}', '\eta', 'p'};

    % ====================================================================
    % 5. Create 4×2 subplots (one per parameter)
    % ====================================================================
    for i = 1:n_params
        subplot(4, 2, i);
        hold on; grid on; box on;

        % Bar plot with group categories I, II, III
        x_categories = {'I', 'II', 'III'};
        h = bar(x_categories, means_all(i, :), ...
                'FaceColor', 'none', ...
                'LineWidth', 2.5, ...
                'EdgeColor', 'flat');          % Use individual edge colours
        h.CData = bar_colors;                  % Assign edge colours per bar

        % Add error bars (standard deviation)
        errorbar(1:3, means_all(i, :), stds_all(i, :), ...
                 'k.', 'LineWidth', 1.5, 'CapSize', 15);

        % Set y-axis limits and tick marks if defined
        if ~any(isnan(ylimits(i, :)))
            ylim(ylimits(i, :));
            num_ticks = 3;
            yticks(linspace(ylimits(i, 1), ylimits(i, 2), num_ticks));
        end

        % Formatting
        set(gca, 'FontSize', fontSize - 4, 'FontName', 'Arial');
        title(titles{i}, 'FontSize', fontSize, 'Interpreter', 'tex');
    end

    % ====================================================================
    % 6. Save the figure
    % ====================================================================
    % Ensure output directory exists
    set(gcf, 'Unit', 'centimeters', 'Position', [3, 10, 18, 26]);
    print('Figure/Fig7E', '-dpng', '-r200');

end