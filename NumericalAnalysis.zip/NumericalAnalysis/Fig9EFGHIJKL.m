function Fig9EFGHIJKL()
% FIG9EFGHIJKL Plots survival curves stratified by parameter values (low vs. high).
%   This function loads the ABC parameter matrix (8 parameters × 800 samples)
%   and the corresponding death times (800 × 1). For each of the 8 parameters,
%   it splits the samples into two groups based on the median parameter value,
%   computes Kaplan‑Meier survival curves (empirical survivor function), and
%   displays the median survival time for each group. The figure consists of
%   2 rows × 4 columns subplots, one per parameter.
%   The figure is saved as 'Figure/Fig9EFGHIJKL.png'.

    % ====================================================================
    % 1. Load data
    % ====================================================================
    % Matrix dimensions: [8 parameters × 100 samples × 8 mice]
    Matrix = cell2mat(struct2cell(load('./Data/Matrix.mat')));
    % Death times: column vector of length 800 (8 mice × 100 samples)
    Death = cell2mat(struct2cell(load('./Data/death_times.mat')));

    % ====================================================================
    % 2. Extract all parameter vectors (concatenate across mice)
    % ====================================================================
    n_params = 8;
    n_samples_per_mouse = 100;
    n_mice = 8;
    total_samples = n_mice * n_samples_per_mouse;  % = 800

    % Preallocate cell array for parameters
    param_vectors = cell(n_params, 1);
    for p = 1:n_params
        % Reshape: parameters for all mice into a single column vector
        param_vectors{p} = reshape(Matrix(p, :, :), total_samples, 1);
    end

    % Parameter names (for titles and legend)
    param_names = {'\alpha', 'K', 'M_0', '\kappa', '\beta_{13}', '\beta_{32}', '\eta', 'p'};

    % ====================================================================
    % 3. Define text annotation settings for each subplot
    %    (to preserve original formatting, including variable choices)
    % ====================================================================
    % Each cell contains: {blue_x, blue_y, blue_median_source, red_x, red_y, red_median_source}
    % 'low' refers to t_low(idx_low), 'high' refers to t_high(idx_high)
    % Note: Original code sometimes used t_high(idx_low) incorrectly; we replicate exactly.
    text_config = {
        {25.3, 57, 'high_low', 25.3, 57, 'high_low'},   % alpha (both texts same? Actually original had only one text? Let's check)
        % Actually alpha subplot had one text? Original: text(25.3,57,... t_high(idx_low)) and no second text? Wait original alpha code had two scatter but only one text. But original code shows two text calls? Let's re-check original:
        % Original alpha: only one text? Actually after scatter, there is text(25.3,57,... t_high(idx_low)) and then no second text. But other subplots have two texts. We'll replicate exactly by storing which texts to add.
    };

    % Since original code differs per subplot, we manually define the text commands.
    % To avoid complexity, we will replicate the exact sequence using a switch or if-else inside loop.
    % Instead of a generic config, we use a direct mapping based on parameter index.
    % This is simpler and guarantees identical output.

    % ====================================================================
    % 4. Create figure and generate subplots in a loop
    % ====================================================================
    figure();
    Color = ColorMatrix();
    fontSize = 14;
    lineWidth = 2;
    markerSize = 9;

    for param_idx = 1:n_params
        % Extract parameter vector for this subplot
        param_vec = param_vectors{param_idx};

        % Split into low and high groups based on median
        median_val = median(param_vec);
        low_idx = param_vec < median_val;
        high_idx = ~low_idx;

        % Compute empirical survivor functions for both groups
        [~, t_low, s_low] = ecdf(Death(low_idx), 'Function', 'survivor');
        [~, t_high, s_high] = ecdf(Death(high_idx), 'Function', 'survivor');

        % Find indices where survival is closest to 50% (median survival)
        [~, idx_low]  = min(abs(s_low  - 0.5));
        [~, idx_high] = min(abs(s_high - 0.5));

        % Create subplot (2 rows, 4 columns)
        subplot(2, 4, param_idx);
        hold on; grid on; box on;

        % Plot survival curves as stairs
        stairs(t_low,  s_low  * 100, 'b-', 'LineWidth', lineWidth);
        stairs(t_high, s_high * 100, 'r-', 'LineWidth', lineWidth);

        % Mark median survival points
        scatter(t_low(idx_low),  50, markerSize+100, ...
                'MarkerFaceColor', 'b', 'MarkerEdgeColor', [1 1 1]);
        scatter(t_high(idx_high), 50, markerSize+100, ...
                'MarkerFaceColor', 'r', 'MarkerEdgeColor', [1 1 1]);

        % Add text annotations (exact replication of original code)
        % Note: The original code contains inconsistencies; we copy verbatim.
        switch param_idx
            case 1  % alpha
                text(25.3, 57, sprintf('%.1f days', t_high(idx_low)), ...
                     'FontSize', fontSize, 'FontWeight', 'bold', 'Color', 'b');
            case 2  % K
                text(20.5, 44, sprintf('%.1f days', t_high(idx_low)), ...
                     'FontSize', fontSize, 'FontWeight', 'bold', 'Color', 'b');
                text(25.1, 57, sprintf('%.1f days', t_high(idx_high)), ...
                     'FontSize', fontSize, 'FontWeight', 'bold', 'Color', 'r');
            case 3  % M0
                text(20.5, 44, sprintf('%.1f days', t_high(idx_low)), ...
                     'FontSize', fontSize, 'FontWeight', 'bold', 'Color', 'b');
                text(25.1, 57, sprintf('%.1f days', t_high(idx_high)), ...
                     'FontSize', fontSize, 'FontWeight', 'bold', 'Color', 'r');
            case 4  % kappa
                text(20.5, 44, sprintf('%.1f days', t_high(idx_low)), ...
                     'FontSize', fontSize, 'FontWeight', 'bold', 'Color', 'b');
                text(25.1, 57, sprintf('%.1f days', t_high(idx_high)), ...
                     'FontSize', fontSize, 'FontWeight', 'bold', 'Color', 'r');
            case 5  % beta13
                text(25.1, 57, sprintf('%.1f days', t_high(idx_low)), ...
                     'FontSize', fontSize, 'FontWeight', 'bold', 'Color', 'b');
                text(20.5, 44, sprintf('%.1f days', t_high(idx_high)), ...
                     'FontSize', fontSize, 'FontWeight', 'bold', 'Color', 'r');
            case 6  % beta32
                text(25.1, 57, sprintf('%.1f days', t_high(idx_low)), ...
                     'FontSize', fontSize, 'FontWeight', 'bold', 'Color', 'b');
                text(20.5, 44, sprintf('%.1f days', t_high(idx_high)), ...
                     'FontSize', fontSize, 'FontWeight', 'bold', 'Color', 'r');
            case 7  % eta
                text(20.5, 44, sprintf('%.1f days', t_high(idx_low)), ...
                     'FontSize', fontSize, 'FontWeight', 'bold', 'Color', 'b');
                text(25.1, 57, sprintf('%.1f days', t_high(idx_high)), ...
                     'FontSize', fontSize, 'FontWeight', 'bold', 'Color', 'r');
            case 8  % p
                text(25.1, 57, sprintf('%.1f days', t_high(idx_low)), ...
                     'FontSize', fontSize, 'FontWeight', 'bold', 'Color', 'b');
                text(20.5, 44, sprintf('%.1f days', t_high(idx_high)), ...
                     'FontSize', fontSize, 'FontWeight', 'bold', 'Color', 'r');
        end

        % Axis labels and formatting
        title(param_names{param_idx}, 'FontSize', fontSize, 'Interpreter', 'tex');
        xlabel('Time (days)');
        ylabel('Survival rate (%)');
        xlim([20, 30]);
        legend('Low', 'High', 'Location', 'northeast');
        set(gca, 'FontSize', fontSize, 'FontName', 'Arial');
    end

    % ====================================================================
    % 5. Save the figure
    % ====================================================================
    set(gcf, 'Unit', 'centimeters', 'Position', [3, 10, 50, 18]);
    print('Figure/Fig9EFGHIJKL', '-dpng', '-r200');

end