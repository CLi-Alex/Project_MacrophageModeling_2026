function solveequation()  % using (3.20) to solve steady state (N, M)

parameter();
global Par

kapmin=0.03;
kapmax=4.5;
dkap=0.03;
M0min=4e4;
M0max=6e6;
dM0=4e4;
dC=300;

kap=kapmin:dkap:kapmax;
I=size(kap,2);
M0=M0min:dM0:M0max;
J=size(M0,2);
fprintf('I*J= %d \n',I*J);
C=dC:dC:(Par.K-dC);
K=size(C,2);

fp=fopen('Srootdata.dat','w');
for i=1:I
    for j=1:J 
        for k=1:K
             if k<=K-1
                if h( C(k), kap(i),M0(j),Par) ==0 || h(C(k),kap(i),M0(j), Par) *h(C(k+1),kap(i),M0(j), Par)  < 0 
                    M1=sM1(C(k), kap(i),M0(j), Par);  
                    M2=sM2(C(k), kap(i),M0(j), Par); 
                    M3=sM3(C(k),kap(i), M0(j), Par); 
                    MM=M1+M2+M3;
                    M1f=M1/MM;
                    M2f=M2/MM;
                    M3f=M3/MM;
                    fprintf(fp,'%10f %10f %10f %10f %10f %10f %10f %10f %10f \n',kap(i),M0(j),C(k), M1,M2, M3,M1f,M2f,M3f);
                end
             else
                if h(C(k), kap(i),M0(j),Par) ==0 
                    M1=sM1(C(k), kap(i),M0(j), Par);  
                    M2=sM2(C(k), kap(i),M0(j), Par); 
                    M3=sM3(C(k), kap(i),M0(j), Par);
                    MM=M1+M2+M3;
                    M1f=M1/MM;
                    M2f=M2/MM;
                    M3f=M3/MM;
                    fprintf(fp,'%10f %10f %10f %10f %10f %10f %10f %10f %10f \n',kap(i),M0(j),C(k), M1,M2, M3,M1f,M2f,M3f);
                end 
             end
        end  
    end
    i
end
fclose(fp);
end






