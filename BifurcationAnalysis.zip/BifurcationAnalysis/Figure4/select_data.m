function select_data()

A=load('Srootdata.dat');

alpmin=0;
etamin=0;

J=(A(:,1)> alpmin & A(:,2)>etamin & A(:,3)>0);
B=A(J,:);
dlmwrite('Srootdataclean.dat',B,' ');

end