function plot_kappa_M0_vary()

fig=figure(1);
set(gcf,'unit','inches','position',[5,5,14.4,3]);  % position: [left, bottom, width, height]
parameter();

subplot(1,3,1)
H1=load('Srootnumber1.dat');
H2=load('Srootnumber2.dat'); 
% H3=load('Srootnumber3.dat');

x = [2.5 4.55 4.55 2.5];
y = [3.3e6 3.3e6 6.1e6 6.1e6];
patch(x,y,[1 0.75 0.82],'FaceAlpha', 0.9) %pink
hold on
scatter(H1(:,1), H1(:,2),[],[0.96 0.87 0.7],'.','LineWidth',0.01); % wheat
hold on
scatter(H2(:,1), H2(:,2),[],[0.68,0.86,0.98],'.','LineWidth',0.01); % skyblue
% plot(H3(:,1), H3(:,2),'.y','LineWidth',1.5); % paint 3 times with yellow

plot([0.27, 0.27],[0,0.08e6],'k','LineWidth',1);
plot([0.9, 0.9],[0,0.08e6],'k','LineWidth',1);
plot([2.1, 2.1],[0,0.08e6],'k','LineWidth',1);
plot([3.3, 3.3],[0,0.08e6],'k','LineWidth',1);
plot([4.2, 4.2],[0,0.08e6],'k','LineWidth',1);

plot([0, 0.05],[3.2e5,3.2e5],'k','LineWidth',1);
plot([0, 0.05],[1.4e6,1.4e6],'k','LineWidth',1);
plot([0, 0.05],[3e6,3e6],'k','LineWidth',1);
plot([0, 0.05],[4.4e6,4.4e6],'k','LineWidth',1);
plot([0, 0.05],[5.4e6,5.4e6],'k','LineWidth',1);

h10=text(0.17,-3.5e5,'$\kappa_1$','FontSize',12);
h20=text(0.9-0.1,-3.5e5,'$\kappa_2$','FontSize',12);
h30=text(2.1-0.1,-3.5e5,'$\kappa_3$','FontSize',12);
h40=text(3.3-0.1,-3.5e5,'$\kappa_4$','FontSize',12);
h50=text(4.2-0.1,-3.5e5,'$\kappa_5$','FontSize',12);
set(h10,'Interpreter','latex');
set(h20,'Interpreter','latex');
set(h30,'Interpreter','latex');
set(h40,'Interpreter','latex');
set(h50,'Interpreter' ,'latex');

h1=text(-0.45,3.6e5,'$M_{01}$','FontSize',12);
h2=text(-0.45,1.4e6+0.4e5,'$M_{02}$','FontSize',12);
h3=text(-0.45,3e6+0.4e5,'$M_{03}$','FontSize',12);
h4=text(-0.45,4.4e6+0.4e5,'$M_{04}$','FontSize',12);
h5=text(-0.45,5.4e6+0.4e5,'$M_{05}$','FontSize',12);
set(h1,'Interpreter','latex');
set(h2,'Interpreter','latex');
set(h3,'Interpreter','latex');
set(h4,'Interpreter','latex');
set(h5,'Interpreter','latex');

text(0.15, 7e5,' Tumorous ','color',[0.647 0.165 0.165],'FontSize',14.5);
text(1.8, 3e6,' Bistable ','color','b','FontSize',14.5);
text(2.89, 5.5e6,' Tumor-free ','color','r','FontSize',14.5);
text(-0.78,6.35e6,'A','FontSize',15);
xlim([0 4.5]);
ylim([0 6e6]);
set(gca,'XTickMode','manual','XTick',[0 1.5 3 4.5]);
set(gca,'YTickMode','manual','YTick',[0 2e6 4e6 6e6]);

h6=xlabel('${\rm Polarization ~ rate ~ of} ~ M_1 ~ (\kappa)$','FontSize',13);
set(h6,'Interpreter','latex');
% ylabel(' M_0 (cells)','FontSize',11);
h60=text(-0.91, 0.65e6,'$ {\rm Baseline~level~of~resting} $', 'FontSize',13, 'Rotation', 90);
h600=text(-0.65, 1.2e6,'$ {\rm macrophages}~ (M_0)$', 'FontSize',13, 'Rotation', 90); 
set(h60,'Interpreter','latex');
set(h600,'Interpreter','latex');

subplot(1,3,2)
H3=load('kappa_change/kappa_change_M0_3up.dat');
H4=load('kappa_change/kappa_change_M0_3down.dat');

x = [0 0.75 0.75 0];
y = [0 0 3e8 3e8];
patch(x,y,[0.96 0.87 0.7],'FaceAlpha', 0.9); %pink
hold on
x = [0.75 4.5 4.5 0.75];
y = [0 0 3e8 3e8];
patch(x,y,[0.68,0.86,0.98],'FaceAlpha', 0.9); %pink
plot([0.75,0.75],[0,3e8],'color',[0.68,0.86,0.98],'LineWidth',1);
plot(H3(:,1),H3(:,2),'m','LineWidth',2);
hold on
plot(H4(:,1),H4(:,2),'--m','LineWidth',2);
plot([0,0.75],[0,0],'--','color',[0 0 1],'LineWidth',2);
plot([0.75,4.5],[0,0],'color',[0 0 1],'LineWidth',2);

xlim([0 4.5]);
ylim([0 3e8]);
text(0.35, 0.84e8,' Tumorous ','color',[0.647 0.165 0.165],'FontSize',14.5,'Rotation', 90);
text(1.4, 1.5e8,' Bistable ','color','b','FontSize',14.5);

hh=text(2.5, 2.7e8,'$ M_0 = 3 \times 10^6$', 'FontSize',13); 
set(hh,'Interpreter','latex');

set(gca,'XTickMode','manual','XTick',[0 1 3 4.5]);
set(gca,'YTickMode','manual','YTick',[0 1e8 2e8 3e8]);

% annotation('arrow',[0.495 0.470],[0.16 0.26]);

h7=xlabel('${\rm Polarization ~ rate ~ of} ~ M_1 ~ (\kappa)$','FontSize',13);
set(h7,'Interpreter','latex');
h70=text(-0.45, 0.65e8,'$ {\rm Steady~ state}~ (C)$', 'FontSize',13, 'Rotation', 90); 
set(h70,'Interpreter','latex');
text(-0.78,3.18e8,'B','FontSize',15);


subplot(1,3,3)
H5=load('kappa_change/kappa_change_M0_5up.dat');
H6=load('kappa_change/kappa_change_M0_5down.dat');

x = [0 0.42 0.42 0];
y = [0 0 3e8 3e8];
patch(x,y,[0.96 0.87 0.7],'FaceAlpha', 0.9); %pink
hold on
x = [0.42 2.88 2.88 0.42];
y = [0 0 3e8 3e8];
patch(x,y,[0.68,0.86,0.98],'FaceAlpha', 0.9); %pink

x = [2.88 4.5 4.5 2.88];
y = [0 0 3e8 3e8];
patch(x,y,[1 0.75 0.82],'FaceAlpha', 0.9); %pink

plot([2.88,2.88],[0,3e8],'color',[0.68,0.86,0.98],'LineWidth',1);
plot([0.42,0.42],[0,3e8],'color',[0.68,0.86,0.98],'LineWidth',1);

plot(H5(:,1),H5(:,2),'m','LineWidth',2);
hold on
plot(H6(:,1),H6(:,2),'--m','LineWidth',2);
plot([0,0.42],[0,0],'--b','LineWidth',2);
plot([0.42,4.5],[0,0],'b','LineWidth',2);

xlim([0 4.5]);
ylim([0 3e8]);
text(0.185, 0.84e8,' Tumorous ','color',[0.647 0.165 0.165],'FontSize',14.5,'Rotation', 90);
text(1.6, 1.5e8,' Bistable ','color','b','FontSize',14.5);
text(2.85, 1.5e8,' Tumor-free ','color','r','FontSize',14.5);

hh1=text(2.4, 2.7e8,'$ M_0 = 5.4 \times 10^6$', 'FontSize',13); 
set(hh1,'Interpreter','latex');

set(gca,'XTickMode','manual','XTick',[0 1 3 4.5]);
set(gca,'YTickMode','manual','YTick',[0 1e8 2e8 3e8]);

h8=xlabel('${\rm Polarization ~ rate ~ of} ~ M_1 ~ (\kappa)$','FontSize',13);
set(h8,'Interpreter','latex');
h90=text(-0.45, 0.65e8,'$ {\rm Steady~ state}~ (C)$', 'FontSize',13, 'Rotation', 90); 
set(h90,'Interpreter','latex');
text(-0.78,3.18e8,'C','FontSize',15);

end