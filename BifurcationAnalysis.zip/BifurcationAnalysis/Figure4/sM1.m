function y =sM1(C, kap,M0, Par) % the right side of M1 

y1 = Par.bet_13*C/(Par.K1+C)+Par.d1 ;
y=kap*M0/y1;
end