function y =h( C, kap,M0,Par) % 
y1= Par.alp*(1+Par.del*(sM2(C, kap,M0, Par)+Par.p*sM3(C, kap,M0, Par)))*(1-C/Par.K);
y2 = Par.eta*(sM1(C, kap,M0, Par)+(1-Par.p)*sM3(C, kap,M0, Par));
y = y1 - y2 ;

end