function solveequation_free()  % using (3.20) to solve steady state (N, M)

parameter();
global Par

kapmin=0.03;
kapmax=4.5;
dkap=0.03;
M0min=4e4;
M0max=6e6;
dM0=4e4;

kap=kapmin:dkap:kapmax;
I=size(kap,2);
M0=M0min:dM0:M0max;
J=size(M0,2);
fprintf('I*J= %d \n',I*J);

fp=fopen('Srootdata_free.dat','w');
for i=1:I
    for j=1:J 
        y1 = kap(i)*M0(j)*(Par.bet_23+Par.d2)*(Par.bet_31+Par.d3)+Par.bet_31*Par.gam*M0(j)*Par.bet_23;
        y2 = Par.d1*(Par.bet_23+Par.d2)*(Par.bet_31+Par.d3);
        y3=(Par.bet_23+Par.d2)*(Par.bet_31+Par.d3);
        M1 = y1/y2;
        M2 = Par.gam*M0(j)/(Par.bet_23+Par.d2);
        M3 = Par.gam*M0(j)*Par.bet_23/y3 ;
        MM=M1+M2+M3;
        M1f=M1/MM;
        M2f=M2/MM;
        M3f=M3/MM;
        fprintf(fp,'%10f %10f %10f %10f %10f %10f %10f %10f %10f \n',kap(i),M0(j),0, M1,M2, M3,M1f,M2f,M3f);
    end
end
fclose(fp);
end






