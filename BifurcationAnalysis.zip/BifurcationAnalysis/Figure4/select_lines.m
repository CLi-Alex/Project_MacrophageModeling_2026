function select_lines()

E=load('Srootdataclean.dat');
kappa=[0.27 0.9 2.1 3.3 4.2];
M0=[3.2e5 1.4e6 3e6 4.4e6 5.4e6];
I=length(E(:,1));
J=length(kappa) ;
K=length(M0) ;

for j=1:J
    fp=fopen(strcat('M0_change/M0_change_kappa_',num2str(j),'.dat'),'w');
    for i=1:I
        if E(i,1)== kappa(j)
            fprintf(fp,'%10f %10f %10f %10f %10f %10f %10f %10f %10f \n',...
                E(i,1),E(i,2),E(i,3), E(i,4),E(i,5), E(i,6),E(i,7),E(i,8),E(i,9));
        end
    end
end

for k=1:K
    fp=fopen(strcat('kappa_change/kappa_change_M0_',num2str(k),'.dat'),'w');
    for i=1:I
        if E(i,2)==M0(k)
            fprintf(fp,'%10f %10f %10f %10f %10f %10f %10f %10f %10f \n',...
                E(i,1),E(i,2),E(i,3), E(i,4),E(i,5), E(i,6),E(i,7),E(i,8),E(i,9));
        end
    end
end



end