function y =sM3(C, kap,M0, Par) % the right side of M3 

y1 = Par.bet_13*C/(Par.K1+C) ;
y2 = Par.bet_32*C/(Par.K2+C)+Par.d3 ;

y3 = y1+Par.d1 ;

y=y1*kap*M0/(y2*y3);
end