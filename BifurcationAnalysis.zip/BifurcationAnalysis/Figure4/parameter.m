function parameter()
global  Par

Par.alp = 0.431;
Par.K=3e8;
Par.del = 1e-9;
Par.p=0.5;
Par.eta = 1.1e-8;
Par.kap=0.4;
Par.gam=0.1;
Par.lam=0.5;
Par.M0=4e5;
Par.bet_13=0.5;
Par.bet_31=0;
Par.bet_23=0;
Par.bet_32=0.5;
Par.K0=3e7;
Par.K1=3e6;
Par.K2=3e6;
Par.d1=0.056;
Par.d2=0.056;
Par.d3=0.056;

Par.x10=2e5;
Par.x20=4e6;
Par.x30=0;
Par.x40=0;


end