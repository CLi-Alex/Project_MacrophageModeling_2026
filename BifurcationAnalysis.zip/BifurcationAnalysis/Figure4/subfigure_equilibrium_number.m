function subfigure_equilibrium_number()

E=load('Srootdataclean.dat');
F=E(:,1:2);
G=unique(F,'row');
l=length(G(:,1)); 
k=length(E(:,1));
fprintf(' k= %d \n',k);
fprintf(' l= %d \n',l);

mp=fopen('Srootnumber.dat','w');
for i=1:l
    h=0.0;
    for j=1:k
        if E(j,1)==G(i,1) && E(j,2)==G(i,2)
            h=h+1;
        end
    end
    
    fprintf(mp,'%10f %10f %d \n',G(i,1), G(i,2), h);
   
end 
fclose(mp);

H=load('Srootnumber.dat');  %  items

 mp1=fopen('Srootnumber1.dat','w');  %  items
 J1=(H(:,3)==1);
 H1=H(J1,:);
 l1=length(H1(:,1));
 for i1=1:l1
 fprintf(mp1,'%10f %10f %d \n',H1(i1,1),H1(i1,2), H1(i1,3));
 end
 fclose(mp1);
 fprintf(' l1= %d \n',l1);
 
 mp2=fopen('Srootnumber2.dat','w');  %  items
 J2=(H(:,3)==2);
 H2=H(J2,:);
 l2=length(H2(:,1));
 for i2=1:l2
 fprintf(mp2,'%10f %10f %d \n',H2(i2,1),H2(i2,2), H2(i2,3));
 end
 fclose(mp2);
 fprintf(' l2= %d \n',l2);
 
 mp3=fopen('Srootnumber3.dat','w');  %  items
 J3=(H(:,3)==3);
 H3=H(J3,:);
 l3=length(H3(:,1));
 for i3=1:l3
 fprintf(mp3,'%10f %10f %d \n',H3(i3,1),H3(i3,2), H3(i3,3));
 end
 fclose(mp3);
 fprintf(' l3= %d \n',l3);
 
 mp4=fopen('Srootnumber4.dat','w');  %  items
 J4=(H(:,3)==4);
 H4=H(J4,:);
 l4=length(H4(:,1));
 for i4=1:l4
 fprintf(mp4,'%10f %10f %d \n',H4(i4,1),H4(i4,2), H4(i4,3));
 end
 fclose(mp4);
 fprintf(' l4= %d \n',l4);
 
 fprintf(' l1+l2+l3+l4 = %d \n',l1+l2+l3+l4);
 fprintf(' l1*1+l2*2+l3*3+l4*4 = %d \n',l1*1+l2*2+l3*3+l4*4);





end