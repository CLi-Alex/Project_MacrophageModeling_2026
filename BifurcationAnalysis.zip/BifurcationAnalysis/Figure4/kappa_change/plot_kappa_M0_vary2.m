function plot_kappa_M0_vary2()

fig=figure(1);
set(gcf,'unit','inches','position',[5,5,4.3,3]);  % position: [left, bottom, width, height]

H10=load('/Users/zhanghaifeng/Desktop/kappa_M0/M0_change/M0_change_kappa_1.dat');
H210=load('/Users/zhanghaifeng/Desktop/kappa_M0/M0_change/M0_change_kappa_2down.dat');
H220=load('/Users/zhanghaifeng/Desktop/kappa_M0/M0_change/M0_change_kappa_2up.dat');
H310=load('/Users/zhanghaifeng/Desktop/kappa_M0/M0_change/M0_change_kappa_3down.dat');
H320=load('/Users/zhanghaifeng/Desktop/kappa_M0/M0_change/M0_change_kappa_3up.dat');
H410=load('/Users/zhanghaifeng/Desktop/kappa_M0/M0_change/M0_change_kappa_4down.dat');
H420=load('/Users/zhanghaifeng/Desktop/kappa_M0/M0_change/M0_change_kappa_4up.dat');
H510=load('/Users/zhanghaifeng/Desktop/kappa_M0/M0_change/M0_change_kappa_5down.dat');
H520=load('/Users/zhanghaifeng/Desktop/kappa_M0/M0_change/M0_change_kappa_5up.dat');


x = [0 6e6 6e6 0];
y = [0 0 1e7 1e7];
patch(x,y,'b','FaceAlpha', 0.008); %pink
hold on
hold on
plot(H10(:,2), H10(:,3) ,'color',[0 1 0.498],'LineWidth',1.5); % 
plot(H210(:,1), H210(:,2) ,'--','color',[0.13333 0.5451 0.13333],'LineWidth',1.5); % 
hold on
plot(H220(:,1), H220(:,2) ,'color',[0.13333 0.5451 0.13333],'LineWidth',1.5); % 
plot(H310(:,1), H310(:,2) ,'--','color',[0 1 1],'LineWidth',1.5); % 
plot(H320(:,1), H320(:,2) ,'color',[0 1 1],'LineWidth',1.5); % 
plot(H410(:,1), H410(:,2) ,'--','color',[0 0.5 1],'LineWidth',1.5); % 
plot(H420(:,1), H420(:,2) ,'color',[0 0.5 1],'LineWidth',1.5); % 
plot(H510(:,1), H510(:,2) ,'--','color',[0 0 1],'LineWidth',1.5); % 
plot(H520(:,1), H520(:,2) ,'color',[0 0 1],'LineWidth',1.5); % 

xlim([0 6e6]);
ylim([0 1e7]);
set(gca,'XTickMode','manual','XTick',[0 6e6],'FontSize',13);
set(gca,'YTickMode','manual','YTick',[0 1e7],'FontSize',13);

end