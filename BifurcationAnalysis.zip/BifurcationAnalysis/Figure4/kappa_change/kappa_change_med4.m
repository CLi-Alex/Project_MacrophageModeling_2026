function kappa_change_med4()

E=load('kappa_change_M0_5.dat');
F=E(:,1);
G=unique(F,'row');
l=length(G(:,1)); 
k=length(E(:,1));
fprintf(' k= %d \n',k);
fprintf(' l= %d \n',l);

mp=fopen('kappa_change_M0_5_number.dat','w');
for i=1:l
    h=0.0;
    for j=1:k
        if E(j,1)==G(i,1)
            h=h+1;
            fprintf(mp,'%10f %10f %d %10f %10f %10f\n', E(j,1), E(j,3), h, E(j,4), E(j,5), E(j,6));
        end    
    end   
end 
fclose(mp);

H=load('kappa_change_M0_5_number.dat');  

J1=(H(:,3)==1);   % steady state: 1-3-2
H1=H(J1,:);
J2=(H(:,3)==2);
H2=H(J2,:);
kappa_2_min=min(H2(:,1));
kappa_2_max=max(H2(:,1));
J = length(H(:,1));

fp4=fopen('kappa_change_M0_5down.dat','w');
for i=1:J
    if (H(i,1) >= kappa_2_min) && (H(i,1) <= kappa_2_max) && (H(i,3) == 1)
        fprintf(fp4,'%10f %10f %10d %10f %10f %10f \n',H(i,1), H(i,2), H(i,3),H(i,4), H(i,5), H(i,6));
    end
end
fclose(fp4);


fp5=fopen('kappa_change_M0_5up.dat','w');
for i=1:J
    if (H(i,1) < kappa_2_min) && (H(i,3) == 1)
        fprintf(fp5,'%10f %10f %10d %10f %10f %10f \n',H(i,1), H(i,2), H(i,3),H(i,4), H(i,5), H(i,6));
    end
end
for i=1:J
    if (H(i,1) > kappa_2_min) && (H(i,1) <= kappa_2_max) && (H(i,3) == 2)
        fprintf(fp4,'%10f %10f %10d %10f %10f %10f \n',H(i,1), H(i,2), H(i,3),H(i,4), H(i,5), H(i,6));
    end
end

fclose(fp5);


end