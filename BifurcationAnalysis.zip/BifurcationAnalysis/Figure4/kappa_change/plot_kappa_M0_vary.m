function plot_kappa_M0_vary()

fig=figure(1);
set(gcf,'unit','inches','position',[5,5,19.2,7]);  % position: [left, bottom, width, height]
H1=load('kappa_change_M0_1.dat');
H21=load('kappa_change_M0_2down.dat');
H22=load('kappa_change_M0_2up.dat');
H31=load('kappa_change_M0_3down.dat');
H32=load('kappa_change_M0_3up.dat');
H41=load('kappa_change_M0_4down.dat');
H42=load('kappa_change_M0_4up.dat');
H51=load('kappa_change_M0_5down.dat');
H52=load('kappa_change_M0_5up.dat');

H10=load('/Users/zhanghaifeng/Desktop/kappa_M0/M0_change/M0_change_kappa_1.dat');
H210=load('/Users/zhanghaifeng/Desktop/kappa_M0/M0_change/M0_change_kappa_2down.dat');
H220=load('/Users/zhanghaifeng/Desktop/kappa_M0/M0_change/M0_change_kappa_2up.dat');
H310=load('/Users/zhanghaifeng/Desktop/kappa_M0/M0_change/M0_change_kappa_3down.dat');
H320=load('/Users/zhanghaifeng/Desktop/kappa_M0/M0_change/M0_change_kappa_3up.dat');
H410=load('/Users/zhanghaifeng/Desktop/kappa_M0/M0_change/M0_change_kappa_4down.dat');
H420=load('/Users/zhanghaifeng/Desktop/kappa_M0/M0_change/M0_change_kappa_4up.dat');
H510=load('/Users/zhanghaifeng/Desktop/kappa_M0/M0_change/M0_change_kappa_5down.dat');
H520=load('/Users/zhanghaifeng/Desktop/kappa_M0/M0_change/M0_change_kappa_5up.dat');

subplot(2,4,1)

x = [0 4.5 4.5 0];
y = [0 0 3e8 3e8];
p=patch(x,y,'r'); %pink
p.FaceAlpha= 0.005;
hold on
plot(H1(:,1), H1(:,3) ,'color',[1 0.6471 0],'LineWidth',1.5); % 
plot(H21(:,1), H21(:,2) ,'--','color',[0.64706 0.16471 0.16471],'LineWidth',1.5); % 
hold on
plot(H22(:,1), H22(:,2) ,'color',[0.64706 0.16471 0.16471],'LineWidth',1.5); % 
plot(H31(:,1), H31(:,2) ,'--','color',[1 0 0],'LineWidth',1.5); % 
plot(H32(:,1), H32(:,2) ,'color',[1 0 0],'LineWidth',1.5); % 
plot(H41(:,1), H41(:,2) ,'--','color',[1 0 1],'LineWidth',1.5); % 
plot(H42(:,1), H42(:,2) ,'color',[1 0 1],'LineWidth',1.5); % 
plot(H51(:,1), H51(:,2) ,'--','color',[0.5412 0.1686 0.8863],'LineWidth',1.5); % 
plot(H52(:,1), H52(:,2) ,'color',[0.5412 0.1686 0.8863],'LineWidth',1.5); % 

xlim([0 4.5]);
ylim([0 3e8]);

annotation('arrow',[0.195 0.170],[0.59 0.63]);

set(gca,'XTickMode','manual','XTick',[0 1.5 3 4.5]);
set(gca,'YTickMode','manual','YTick',[0 1e8 2e8 3e8]);
grid on;
h1=xlabel('${\rm Polarization ~ rate ~ of} ~ M_1 ~ (\kappa)$','FontSize',13);
set(h1,'Interpreter','latex');
h10=ylabel('$ {\rm Steady~ state}~ (C)$', 'FontSize',13, 'Rotation', 90); 
set(h10,'Interpreter','latex');
h11=text(2.5,2.55e8,'$M_{01}= 3.2 \times 10^5$','color',[1 0.6471 0],'FontSize',13);
set(h11,'Interpreter','latex');
h12=text(2.5,2.34e8,'$M_{02}= 1.4 \times 10^6$','color',[0.64706 0.16471 0.16471],'FontSize',13);
set(h12,'Interpreter','latex');
h13=text(2.5,2.12e8,'$M_{03}= 3 \times 10^6$','color',[1 0 0],'FontSize',13);
set(h13,'Interpreter','latex');
h14=text(2.5,1.89e8,'$M_{04}= 4.4 \times 10^6$','color',[1 0 1],'FontSize',13);
set(h14,'Interpreter','latex');
h15=text(2.5,1.67e8,'$M_{05}= 5.4 \times 10^6$','color',[0.5412 0.1686 0.8863],'FontSize',13);
set(h15,'Interpreter','latex');

text(-0.70,3.14e8,'A','FontSize',15);

subplot(2,4,2)

x = [0 4.5 4.5 0];
y = [0 0 4e7 4e7];
p=patch(x,y,'r'); %pink
p.FaceAlpha= 0.005;
hold on
plot(H1(:,1), H1(:,4) ,'color',[1 0.6471 0],'LineWidth',1.5); % 
plot(H21(:,1), H21(:,4) ,'--','color',[0.64706 0.16471 0.16471],'LineWidth',1.5); % 
hold on
plot(H22(:,1), H22(:,4) ,'color',[0.64706 0.16471 0.16471],'LineWidth',1.5); % 
plot(H31(:,1), H31(:,4) ,'--','color',[1 0 0],'LineWidth',1.5); % 
plot(H32(:,1), H32(:,4) ,'color',[1 0 0],'LineWidth',1.5); % 
plot(H41(:,1), H41(:,4) ,'--','color',[1 0 1],'LineWidth',1.5); % 
plot(H42(:,1), H42(:,4) ,'color',[1 0 1],'LineWidth',1.5); % 
plot(H51(:,1), H51(:,4) ,'--','color',[0.5412 0.1686 0.8863],'LineWidth',1.5); % 
plot(H52(:,1), H52(:,4) ,'color',[0.5412 0.1686 0.8863],'LineWidth',1.5); % 

xlim([0 4.5]);
ylim([0 4e7]);

set(gca,'XTickMode','manual','XTick',[0 1.5 3 4.5]);
% set(gca,'YTickMode','manual','YTick',[0 1e8 2e8 3e8]);
grid on;
h2=xlabel('${\rm Polarization ~ rate ~ of} ~ M_1 ~ (\kappa)$','FontSize',13);
set(h2,'Interpreter','latex');
h20=ylabel('$ {\rm Steady~ state}~ (M_1)$', 'FontSize',13, 'Rotation', 90); 
set(h20,'Interpreter','latex');
text(-0.70,4.2e7,'B','FontSize',15);

subplot(2,4,3)

x = [0 4.5 4.5 0];
y = [0 0 2.4e8 2.4e8];
p=patch(x,y,'r'); %pink
p.FaceAlpha= 0.005;
hold on
plot(H1(:,1), H1(:,5) ,'color',[1 0.6471 0],'LineWidth',1.5); % 
plot(H21(:,1), H21(:,5) ,'--','color',[0.64706 0.16471 0.16471],'LineWidth',1.5); % 
hold on
plot(H22(:,1), H22(:,5) ,'color',[0.64706 0.16471 0.16471],'LineWidth',1.5); % 
plot(H31(:,1), H31(:,5) ,'--','color',[1 0 0],'LineWidth',1.5); % 
plot(H32(:,1), H32(:,5) ,'color',[1 0 0],'LineWidth',1.5); % 
plot(H41(:,1), H41(:,5) ,'--','color',[1 0 1],'LineWidth',1.5); % 
plot(H42(:,1), H42(:,5) ,'color',[1 0 1],'LineWidth',1.5); % 
plot(H51(:,1), H51(:,5) ,'--','color',[0.5412 0.1686 0.8863],'LineWidth',1.5); % 
plot(H52(:,1), H52(:,5) ,'color',[0.5412 0.1686 0.8863],'LineWidth',1.5); % 

xlim([0 4.5]);
ylim([0 2.4e8]);

set(gca,'XTickMode','manual','XTick',[0 1.5 3 4.5]);
set(gca,'YTickMode','manual','YTick',[0 1e8 2e8]);
grid on;
h3=xlabel('${\rm Polarization ~ rate ~ of} ~ M_1 ~ (\kappa)$','FontSize',13);
set(h3,'Interpreter','latex');
h30=ylabel('$ {\rm Steady~ state}~ (M_2)$', 'FontSize',13, 'Rotation', 90); 
set(h30,'Interpreter','latex');
text(-0.70,2.54e8,'C','FontSize',15);

subplot(2,4,4)

x = [0 4.5 4.5 0];
y = [0 0 3e7 3e7];
p=patch(x,y,'r'); %pink
p.FaceAlpha= 0.005;
hold on
plot(H1(:,1), H1(:,6) ,'color',[1 0.6471 0],'LineWidth',1.5); % 
plot(H21(:,1), H21(:,6) ,'--','color',[0.64706 0.16471 0.16471],'LineWidth',1.5); % 
hold on
plot(H22(:,1), H22(:,6) ,'color',[0.64706 0.16471 0.16471],'LineWidth',1.5); % 
plot(H31(:,1), H31(:,6) ,'--','color',[1 0 0],'LineWidth',1.5); % 
plot(H32(:,1), H32(:,6) ,'color',[1 0 0],'LineWidth',1.5); % 
plot(H41(:,1), H41(:,6) ,'--','color',[1 0 1],'LineWidth',1.5); % 
plot(H42(:,1), H42(:,6) ,'color',[1 0 1],'LineWidth',1.5); % 
plot(H51(:,1), H51(:,6) ,'--','color',[0.5412 0.1686 0.8863],'LineWidth',1.5); % 
plot(H52(:,1), H52(:,6) ,'color',[0.5412 0.1686 0.8863],'LineWidth',1.5); % 

xlim([0 4.5]);
ylim([0 3e7]);

set(gca,'XTickMode','manual','XTick',[0 1.5 3 4.5]);
set(gca,'YTickMode','manual','YTick',[0 1e7 2e7 3e7]);
grid on;
h4=xlabel('${\rm Polarization ~ rate ~ of} ~ M_1 ~ (\kappa)$','FontSize',13);
set(h4,'Interpreter','latex');
h40=ylabel('$ {\rm Steady~ state}~ (M_3)$', 'FontSize',13, 'Rotation', 90); 
set(h40,'Interpreter','latex');
text(-0.70,3.14e7,'D','FontSize',15);

subplot(2,4,5)

x = [0 6e6 6e6 0];
y = [0 0 3e8 3e8];
patch(x,y,'b','FaceAlpha', 0.008); %pink
hold on
hold on
plot(H10(:,2), H10(:,3) ,'color',[0 1 0.498],'LineWidth',1.5); % 
plot(H210(:,1), H210(:,2) ,'--','color',[0.13333 0.5451 0.13333],'LineWidth',1.5); % 
hold on
plot(H220(:,1), H220(:,2) ,'color',[0.13333 0.5451 0.13333],'LineWidth',1.5); % 
plot(H310(:,1), H310(:,2) ,'--','color',[0 1 1],'LineWidth',1.5); % 
plot(H320(:,1), H320(:,2) ,'color',[0 1 1],'LineWidth',1.5); % 
plot(H410(:,1), H410(:,2) ,'--','color',[0 0.5 1],'LineWidth',1.5); % 
plot(H420(:,1), H420(:,2) ,'color',[0 0.5 1],'LineWidth',1.5); % 
plot(H510(:,1), H510(:,2) ,'--','color',[0 0 1],'LineWidth',1.5); % 
plot(H520(:,1), H520(:,2) ,'color',[0 0 1],'LineWidth',1.5); % 

xlim([0 6e6]);
ylim([0 3e8]);
set(gca,'XTickMode','manual','XTick',[0 2e6 4e6 6e6]);
set(gca,'YTickMode','manual','YTick',[0 1e8 2e8 3e8]);
grid on;
h5=text(1.1e6, -4.0e7,'$ {\rm Baseline~level~of~resting} $','FontSize',13);
h51=text(1.5e6, -6.7e7,'$ {\rm macrophages}~ (M_0)$', 'FontSize',13); 
set(h5,'Interpreter','latex');
set(h51,'Interpreter','latex');
h50=ylabel('$ {\rm Steady~ state}~ (C)$', 'FontSize',13, 'Rotation', 90); 
set(h50,'Interpreter','latex');
h51=text(4.3e6,2.56e8,'$\kappa_1= 0.27$','color',[0 1 0.498],'FontSize',13);
set(h51,'Interpreter','latex');
h52=text(4.3e6,2.36e8,'$\kappa_2= 0.9 $','color',[0.13333 0.5451 0.13333],'FontSize',13);
set(h52,'Interpreter','latex');
h53=text(4.3e6,2.16e8,'$\kappa_3= 2.1 $','color',[0 1 1],'FontSize',13);
set(h53,'Interpreter','latex');
h54=text(4.3e6,1.96e8,'$\kappa_4= 3.3 $','color',[0 0.5 1],'FontSize',13);
set(h54,'Interpreter','latex');
h55=text(4.3e6,1.76e8,'$\kappa_5= 4.2 $','color',[0 0 1],'FontSize',13);
set(h55,'Interpreter','latex');

annotation('arrow',[0.195 0.170],[0.117 0.157]);

text(-0.95e6,3.17e8,'E','FontSize',15);

subplot(2,4,6)

x = [0 6e6 6e6 0];
y = [0 0 4e7 4e7];
patch(x,y,'b','FaceAlpha', 0.008); %pink
hold on
plot(H10(:,2), H10(:,4) ,'color',[0 1 0.498],'LineWidth',1.5); % 
plot(H210(:,1), H210(:,4) ,'--','color',[0.13333 0.5451 0.13333],'LineWidth',1.5); % 
hold on
plot(H220(:,1), H220(:,4) ,'color',[0.13333 0.5451 0.13333],'LineWidth',1.5); % 
plot(H310(:,1), H310(:,4) ,'--','color',[0 1 1],'LineWidth',1.5); % 
plot(H320(:,1), H320(:,4) ,'color',[0 1 1],'LineWidth',1.5); % 
plot(H410(:,1), H410(:,4) ,'--','color',[0 0.5 1],'LineWidth',1.5); % 
plot(H420(:,1), H420(:,4) ,'color',[0 0.5 1],'LineWidth',1.5); % 
plot(H510(:,1), H510(:,4) ,'--','color',[0 0 1],'LineWidth',1.5); % 
plot(H520(:,1), H520(:,4) ,'color',[0 0 1],'LineWidth',1.5); % 

xlim([0 6e6]);
ylim([0 4e7]);
set(gca,'XTickMode','manual','XTick',[0 2e6 4e6 6e6]);
% set(gca,'YTickMode','manual','YTick',[0 1e8 2e8 3e8]);
grid on;
h6=text(1.1e6, -5.2e6,'$ {\rm Baseline~level~of~resting} $','FontSize',13);
h61=text(1.5e6, -8.7e6,'$ {\rm macrophages}~ (M_0)$', 'FontSize',13); 
set(h6,'Interpreter','latex');
set(h61,'Interpreter','latex');
h60=ylabel('$ {\rm Steady~ state}~ (M_1)$', 'FontSize',13, 'Rotation', 90); 
set(h60,'Interpreter','latex');
text(-0.95e6,4.2e7,'F','FontSize',15);


subplot(2,4,7)

x = [0 6e6 6e6 0];
y = [0 0 2.4e8 2.4e8];
patch(x,y,'b','FaceAlpha', 0.008); %pink
hold on
plot(H10(:,2), H10(:,5) ,'color',[0 1 0.498],'LineWidth',1.5); % 
plot(H210(:,1), H210(:,5) ,'--','color',[0.13333 0.5451 0.13333],'LineWidth',1.5); % 
hold on
plot(H220(:,1), H220(:,5) ,'color',[0.13333 0.5451 0.13333],'LineWidth',1.5); % 
plot(H310(:,1), H310(:,5) ,'--','color',[0 1 1],'LineWidth',1.5); % 
plot(H320(:,1), H320(:,5) ,'color',[0 1 1],'LineWidth',1.5); % 
plot(H410(:,1), H410(:,5) ,'--','color',[0 0.5 1],'LineWidth',1.5); % 
plot(H420(:,1), H420(:,5) ,'color',[0 0.5 1],'LineWidth',1.5); % 
plot(H510(:,1), H510(:,5) ,'--','color',[0 0 1],'LineWidth',1.5); % 
plot(H520(:,1), H520(:,5) ,'color',[0 0 1],'LineWidth',1.5); % 

xlim([0 6e6]);
ylim([0 2.4e8]);
set(gca,'XTickMode','manual','XTick',[0 2e6 4e6 6e6]);
set(gca,'YTickMode','manual','YTick',[0 1e8 2e8]);
grid on;
h7=text(1.1e6, -3.2e7,'$ {\rm Baseline~level~of~resting} $','FontSize',13);
h71=text(1.5e6, -5.3e7,'$ {\rm macrophages}~ (M_0)$', 'FontSize',13); 
set(h7,'Interpreter','latex');
set(h71,'Interpreter','latex');
h70=ylabel('$ {\rm Steady~ state}~ (M_2)$', 'FontSize',13, 'Rotation', 90); 
set(h70,'Interpreter','latex');
text(-0.95e6,2.54e8,'G','FontSize',15);

subplot(2,4,8)

x = [0 6e6 6e6 0];
y = [0 0 3e7 3e7];
patch(x,y,'b','FaceAlpha', 0.008); %pink
hold on
plot(H10(:,2), H10(:,6) ,'color',[0 1 0.498],'LineWidth',1.5); % 
plot(H210(:,1), H210(:,6) ,'--','color',[0.13333 0.5451 0.13333],'LineWidth',1.5); % 
hold on
plot(H220(:,1), H220(:,6) ,'color',[0.13333 0.5451 0.13333],'LineWidth',1.5); % 
plot(H310(:,1), H310(:,6) ,'--','color',[0 1 1],'LineWidth',1.5); % 
plot(H320(:,1), H320(:,6) ,'color',[0 1 1],'LineWidth',1.5); % 
plot(H410(:,1), H410(:,6) ,'--','color',[0 0.5 1],'LineWidth',1.5); % 
plot(H420(:,1), H420(:,6) ,'color',[0 0.5 1],'LineWidth',1.5); % 
plot(H510(:,1), H510(:,6) ,'--','color',[0 0 1],'LineWidth',1.5); % 
plot(H520(:,1), H520(:,6) ,'color',[0 0 1],'LineWidth',1.5); % 

xlim([0 6e6]);
ylim([0 3e7]);
set(gca,'XTickMode','manual','XTick',[0 2e6 4e6 6e6]);
set(gca,'YTickMode','manual','YTick',[0 1e7 2e7 3e7]);
grid on;
h8=text(1.1e6, -4.0e6,'$ {\rm Baseline~level~of~resting} $','FontSize',13);
h81=text(1.5e6, -6.7e6,'$ {\rm macrophages}~ (M_0)$', 'FontSize',13); 
set(h8,'Interpreter','latex');
set(h81,'Interpreter','latex');
h80=ylabel('$ {\rm Steady~ state}~ (M_3)$', 'FontSize',13, 'Rotation', 90); 
set(h80,'Interpreter','latex');
text(-0.95e6,3.17e7,'H','FontSize',15);
end