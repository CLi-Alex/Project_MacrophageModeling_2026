function plot_kappa_M0_vary1()

fig=figure(1);
set(gcf,'unit','inches','position',[5,5,4.3,3]);  % position: [left, bottom, width, height]
H1=load('kappa_change_M0_1.dat');
H21=load('kappa_change_M0_2down.dat');
H22=load('kappa_change_M0_2up.dat');
H31=load('kappa_change_M0_3down.dat');
H32=load('kappa_change_M0_3up.dat');
H41=load('kappa_change_M0_4down.dat');
H42=load('kappa_change_M0_4up.dat');
H51=load('kappa_change_M0_5down.dat');
H52=load('kappa_change_M0_5up.dat');


x = [0 4.5 4.5 0];
y = [0 0 3e8 3e8];
p=patch(x,y,'r'); %pink
p.FaceAlpha= 0.005;
hold on
plot(H1(:,1), H1(:,3) ,'color',[1 0.6471 0],'LineWidth',1.5); % 
plot(H21(:,1), H21(:,2) ,'--','color',[0.64706 0.16471 0.16471],'LineWidth',1.5); % 
hold on
plot(H22(:,1), H22(:,2) ,'color',[0.64706 0.16471 0.16471],'LineWidth',1.5); % 
plot(H31(:,1), H31(:,2) ,'--','color',[1 0 0],'LineWidth',1.5); % 
plot(H32(:,1), H32(:,2) ,'color',[1 0 0],'LineWidth',1.5); % 
plot(H41(:,1), H41(:,2) ,'--','color',[1 0 1],'LineWidth',1.5); % 
plot(H42(:,1), H42(:,2) ,'color',[1 0 1],'LineWidth',1.5); % 
plot(H51(:,1), H51(:,2) ,'--','color',[0.5412 0.1686 0.8863],'LineWidth',1.5); % 
plot(H52(:,1), H52(:,2) ,'color',[0.5412 0.1686 0.8863],'LineWidth',1.5); % 

xlim([0.3 2.8]);
ylim([0 1e7]);

set(gca,'XTickMode','manual','XTick',[0.4 2.8],'FontSize',13);
set(gca,'YTickMode','manual','YTick',[0 1e7],'FontSize',13);

end