function plot_kappa_vary()
fig=figure(1);
set(gcf,'unit','inches','position',[5,5,14.4,3]);  % position: [left, bottom, width, height]

subplot(1,3,1)
H1=load('kappa_change_M0_2.dat');
H2=load('kappa_change_M0_2down.dat');
H3=load('kappa_change_M0_2up.dat');

  
% plot(H1(:,2), H1(:,3) ,'color',[1 0.5 0.6],'LineWidth',1.5); % paint 1 times with pink
% hold on
plot(H2(:,1), H2(:,2) ,'color',[0 0.5 1],'LineWidth',1.5); % paint 1 times with pink
hold on
plot(H3(:,1), H3(:,2) ,'color',[1 0.5 1],'LineWidth',1.5); % paint 1 times with pink




end