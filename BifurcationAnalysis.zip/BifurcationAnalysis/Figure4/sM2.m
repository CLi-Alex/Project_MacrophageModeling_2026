function y =sM2(C, kap, M0, Par) % the right side of M2 

y1 = Par.bet_13*C/(Par.K1+C) ;
y2 = Par.bet_32*C/(Par.K2+C);

y3 = y1+Par.d1 ;
y4 = y2+Par.d3 ;

y5=Par.gam*M0*y3*y4*(1+Par.lam*C/(Par.K0+C));
y6=y5+ y1*y2*M0*kap ;

y7=y3*Par.d2*y4;

y=y6/y7;

end